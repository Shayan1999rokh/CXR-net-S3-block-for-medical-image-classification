# CXR-Net Research Kit — modular PyTorch implementation

**Paper:** Raeisi, Rokhva, Roshanzamir & Ahmadi Lashaki (2025), *An accurate attention based method for multi-tasking X-ray classification*, **Multimedia Tools and Applications**. DOI: [10.1007/s11042-025-21105-5](https://doi.org/10.1007/s11042-025-21105-5).

**Status:** fully runnable **research-grade interpretation and extension**, **NOT an exact reproduction of unknown original source code**. The PDF does not disclose sufficient parameters or an unambiguous Figure 4/Algorithm 1 matching implementation to claim exact replication. See [paper-to-code mapping](docs/PAPER_MAPPING.md) and [unresolved details](docs/DESIGN_DECISIONS.md).

> Research-only software. **Never use this software for clinical diagnosis without independent clinical validation.** Paper-reported accuracies are **not** results achieved or guaranteed by this package.

## 1. Installation

Python 3.10+ and PyTorch are required. For GPU, use an appropriate official PyTorch/CUDA installation before installing this project. CPU also works, but full training is slow.

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -e ".[test]"
pytest -q
```

CLI is available as `cxrnet` or `python -m cxrnet`.

## 2. Prepare REAL datasets (not included)

Download licensed/public datasets from the original sources in the paper. **No radiographs or manuscript PDF are redistributed.** Suggested structure:

```text
data/raw/
  chest/
    normal/001.jpg
    bacterial_pneumonia/002.jpg
    viral_pneumonia/003.jpg
  fracture/
    fractured/001.png
    not_fractured/002.png
  shoulder/
    a1/001.png
    c1/002.png
    d1/003.png
    others/004.png
```

You can also preserve official dataset partitions:

```text
data/raw/fracture/train/fractured/xxx.png
.../val/fractured/yyy.png
.../test/fractured/zzz.png
```

For non-shared directory layouts, rename/restructure your folder tree or adjust `data.tasks[*].folder` and `classes` in YAML. **Never assume that an arbitrary label name is equivalent to the paper label.** See [data documentation](docs/DATA_PREPARATION.md).

**Strongly recommended for clinical experiments:** supply a CSV with columns `path,patient_id`, where `path` is relative to `data/raw`, and enable `data.split.require_patient_ids: true`. When patient IDs are not known, the toolkit warns that independence between patients is unproven. Identical-byte duplicates across splits are checked by default.

```bash
cxrnet --config configs/default.yaml index --patient-map patient_ids.csv
cxrnet --config configs/default.yaml split
cxrnet --config configs/default.yaml audit
```

Without patient IDs, use `cxrnet index` (no `--patient-map`) for **algorithm testing only**, not clinical performance claims.

## 3. Multi-domain pretraining on TRAIN partitions only

```bash
cxrnet --config configs/default.yaml pretrain --epochs 200
```

Pretraining uses **one shared CNN backbone and three independent classifier heads** (Chest 3-way, Fracture 2-way, Shoulder 4-way). Every domain contributes its **training set only**; validation monitors learning; **test data are never read in pretraining**. This resolves an important source-paper ambiguity.

Checkpoint: `runs/default/pretraining/best.pt`

## 4. Fine-tune separately for each task

```bash
cxrnet --config configs/default.yaml finetune --domain chest \
  --checkpoint runs/default/pretraining/best.pt --epochs 100
cxrnet --config configs/default.yaml finetune --domain fracture \
  --checkpoint runs/default/pretraining/best.pt --epochs 100
cxrnet --config configs/default.yaml finetune --domain shoulder \
  --checkpoint runs/default/pretraining/best.pt --epochs 100
```

Each run writes `best.pt`, `history.csv`, `history.json`, `loss.png`, `test_metrics.json`, `test_predictions.csv`, `test_confusion_matrix.png`, `summary.json`, and `resolved_config.yaml` under its run folder. The best checkpoint is selected **only by validation**. The final test is evaluated **once** after selection. If you need strict one-time external evaluation, reserve an independent external test and do not repeatedly adapt methods using test results.

## 5. Baseline scratch training (no pretraining)

```bash
cxrnet --config configs/default.yaml train --domain chest --epochs 100
```

Checkpoint: `runs/default/scratch_chest/best.pt`.

## 6. Evaluate / predict / Grad-CAM / complexity

```bash
cxrnet --config configs/default.yaml evaluate --domain chest \
  --checkpoint runs/default/finetune_chest/best.pt
cxrnet --config configs/default.yaml predict --domain chest \
  --checkpoint runs/default/finetune_chest/best.pt --image path/to/image.jpg
cxrnet --config configs/default.yaml gradcam --domain chest \
  --checkpoint runs/default/finetune_chest/best.pt --image path/to/image.jpg \
  --output runs/gradcam_chest.png
cxrnet --config configs/default.yaml benchmark --domain chest --batch-size 1
```

Metrics: accuracy, balanced accuracy, macro/weighted F1, macro precision and recall, class-wise sensitivity/specificity and confusion counts, ROC AUC when defined, CE loss, expected calibration error and saved predictions. Confidence values are **uncalibrated**; Grad-CAM heatmaps must not be interpreted as proof of causal lesion localization. Benchmarks report parameter count, throughput, latency and CUDA memory where applicable; **FLOPs are intentionally not claimed** without a validated profiler.

## 7. Ablations (validation-selected; no test peeking)

```bash
cxrnet --config configs/default.yaml ablate --domain chest --epochs 30 \
  --modes none self spatial s3
```

Each variant uses the same seed, splits and optimizer settings. The summary is written to `runs/default/ablation_chest/validation_comparison.csv`; **test data are not evaluated by this command**. Select your final method *on validation only*. Other architectural toggles (`model.fusion: sum`, `model.s3_fusion: diagram`) are available through independent YAML experiment configurations.

## 8. Contrast comparisons (paper Table 2, improved protocol)

```bash
cxrnet --config configs/default.yaml contrast-sweep --domain chest --epochs 30 \
  --methods equalize factor_1.2 factor_1.4 factor_1.6
# For CLAHE, first: pip install -e ".[clahe]"
# Then include "clahe" in --methods.
```

This selects contrast **only on validation data**, unlike the paper wording about comparing techniques on test. Input options are `none`, `equalize`, `clahe`, `factor_1.2`, `factor_1.4`, `factor_1.6`. The 20/40/60% versions are PIL-specific assumptions, not asserted original preprocessing equations.

## 9. Quick synthetic end-to-end demonstration (NOT real data)

```bash
python scripts/create_synthetic_data.py --output data/raw --per-class 16
cxrnet --config configs/default.yaml index
cxrnet --config configs/default.yaml split
cxrnet --config configs/default.yaml audit
cxrnet --config configs/default.yaml pretrain --epochs 1
cxrnet --config configs/default.yaml finetune --domain chest \
  --checkpoint runs/default/pretraining/best.pt --epochs 1
```

For CPU smoke tests, edit `image_size` to `32`, `model.channels` to `[8,12]`, `attention_heads` to `4`, and `batch_size` to `4`, adjusting config carefully. Synthetic images only demonstrate software operation; their metrics are scientifically meaningless.

## 10. Design controls and important differences vs paper

- **S3, two variants**: `s3_fusion: algorithm` adds self-attention and spatial-attention features (Algorithm 1, page 10), whereas `diagram` concatenates and projects them (approximation of Figure 4, page 9).
- **Hierarchical CBR-Concatenation**: stages follow the figure-level motif, but undocumented kernel widths and spatial reductions are **engineering assumptions**, not paper-proven values.
- **Contrast**: a factor of 1.4 using PIL is a reproducible interpretation of paper's "40% contrast"; the exact original contrast formula is unspecified.
- **Augmentation**: applied **online to training only**. Horizontal flipping and ±10° rotations are configurable; vertical flipping defaults to zero because it may violate anatomy. Balanced epoch sampler gives per-class balanced *train* draw counts.
- **Head**: Adaptive Average Pooling -> Flatten -> 2 hidden Dense + final Dense (three Dense layers total). Paper Figure 2 shows ambiguous Flatten/AvgPool ordering.
- **Softmax/Cross Entropy**: network returns raw logits; PyTorch `CrossEntropyLoss` internally handles log-softmax; inference applies explicit softmax.
- **Multi-domain pretraining**: domain-specific heads prevent a single fictitious 9-class ontology and isolate splits. The paper does not specify exactly how its multitasking output was implemented.

Read [PAPER_MAPPING.md](docs/PAPER_MAPPING.md), [DESIGN_DECISIONS.md](docs/DESIGN_DECISIONS.md), [DATA_PREPARATION.md](docs/DATA_PREPARATION.md), and [RESEARCH_CHECKLIST.md](docs/RESEARCH_CHECKLIST.md) before reporting results.

## Repository map

```text
cxrnet/
  config.py                YAML -> validated dataclasses
  utils.py                 reproducible seeds, metadata
  cli.py                   all command-line workflows
  data/manifest.py         import/index image paths and patient map
  data/splitting.py        image-level and patient-group 70/20/10 split
  data/audit.py            disjointness and duplicate checks
  data/transforms.py       contrast / normalization / train augmentation
  data/balancing.py        train-only exact class-balanced sampling
  data/datasets.py         dataset and dataloader
  model/blocks.py          CBR + hierarchy concat/sum stages
  model/attention.py       QKV attention, spatial attention and S3
  model/backbone.py        stage composition
  model/classifier.py      classification head
  model/network.py         single-task and multi-domain versions
  training/optimizer.py    CE weighting, optimizer and scheduler
  training/engine.py       train and evaluate steps
  training/stages.py       domain pretraining, scratch, fine-tuning
  training/checkpoints.py  checkpoint save/load/provenance
  evaluation/metrics.py   full multiclass metrics
  evaluation/plots.py     confusion matrices and loss curves
  evaluation/inference.py single-image inference
  evaluation/ablations.py validation-only attention ablations
  evaluation/contrast_sweep.py validation-only contrast ablations
  evaluation/explain.py   Grad-CAM
  evaluation/benchmark.py parameters, runtime, memory
configs/default.yaml        defaults; modify for your compute/data
scripts/create_synthetic_data.py   demonstrator (not real X-rays)
tests/                     code and guardrail checks
```

## License

The newly written code in this repository is released under MIT (see `LICENSE`). Original paper, figures, and datasets are not included or relicensed. The project is not an official implementation and is not affiliated with Springer Nature.
