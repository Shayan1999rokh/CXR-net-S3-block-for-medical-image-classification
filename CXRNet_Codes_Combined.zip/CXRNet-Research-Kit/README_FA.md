# راهنمای فارسی بسته CXR-Net / S3

این بسته یک **پیاده‌سازی مستقل، ماژولار و قابل‌اجرا با PyTorch** بر اساس مقاله ۲۰۲۵ با DOI `10.1007/s11042-025-21105-5` است. نسخه رسمی نویسندگان در اختیار این پروژه نیست. مقاله ابعاد لایه‌ها، Kernelها، Optimizer و چند جزئیات مهم معماری را دقیق بیان نکرده است؛ این موارد در کد با فرض‌های صریح و قابل‌تغییر پیاده‌سازی شده‌اند. بنابراین بدون کد اصلی نمی‌توان ادعای «بازتولید دقیق» داشت.

## اجزای پروژه

- **`cxrnet/data/`**: شناسایی تصاویر، برچسب‌ها، شناسه بیمار، Split مستقل، کنترل تکراری‌بودن فایل‌ها، Contrast Enhancement، Augmentation مخصوص Train و توازن کلاس‌ها.
- **`cxrnet/model/`**: بلوک‌های CBR، Feature Fusion سلسله‌مراتبی، Self-Attention، Spatial Attention، بلوک S3، طبقه‌بند و مدل‌های تک‌وظیفه‌ای و چنددامنه‌ای.
- **`cxrnet/training/`**: Pretraining چنددامنه‌ای با سرهای مستقل، Fine-tuning، آموزش از صفر، Cross-Entropy، Optimizer، Scheduler، Early Stopping و Checkpoint.
- **`cxrnet/evaluation/`**: Metricهای کامل، Confusion Matrix، Accuracy/Recall/F1/AUC، حساسیت/ویژگی هر کلاس، بازه اطمینان، Calibration Error، پیش‌بینی، Grad-CAM، Benchmark، Ablation و مقایسه روش‌های کنتراست.
- **`tests/`**: آزمون‌های واحد و تست یکپارچه از ساخت داده آزمایشی تا ارزیابی.

## نصب

در ترمینال، داخل پوشه پروژه:

```bash
pip install -e ".[test]"
python -m pytest -q
```

برای CLAHE:

```bash
pip install -e ".[clahe]"
```

## ساختار داده‌ها

```text
data/raw/chest/normal/*.jpg
data/raw/chest/bacterial_pneumonia/*.jpg
data/raw/chest/viral_pneumonia/*.jpg
data/raw/fracture/fractured/*.png
data/raw/fracture/not_fractured/*.png
data/raw/shoulder/a1/*.png
data/raw/shoulder/c1/*.png
data/raw/shoulder/d1/*.png
data/raw/shoulder/others/*.png
```

فایل‌های دیتاست در ZIP نیستند و باید جداگانه تهیه شوند. بهتر است شناسه واقعی بیمار را با یک CSV دارای ستون‌های `path,patient_id` فراهم کنید و `require_patient_ids: true` قرار دهید. بدون شناسه بیمار، هیچ تضمینی برای عدم هم‌پوشانی بیماران در Train/Test وجود ندارد.

## دستورات اصلی

```bash
# ۱. ساخت فهرست داده‌ها و تقسیم بدون نشت اطلاعات
python -m cxrnet --config configs/default.yaml index --patient-map patient_ids.csv
python -m cxrnet --config configs/default.yaml split
python -m cxrnet --config configs/default.yaml audit

# ۲. آموزش اولیه در سه حوزه بر اساس فقط Train
python -m cxrnet --config configs/default.yaml pretrain --epochs 200

# ۳. Fine-tuning طبقه‌بندی Chest
python -m cxrnet --config configs/default.yaml finetune --domain chest \
  --checkpoint runs/default/pretraining/best.pt --epochs 100

# ۴. مقایسه ۴ حالت Attention، فقط روی Validation
python -m cxrnet --config configs/default.yaml ablate --domain chest --epochs 30

# ۵. مقایسه روش‌های کنتراست، فقط روی Validation
python -m cxrnet --config configs/default.yaml contrast-sweep --domain chest --epochs 30
```

**نکته:** در Windows PowerShell می‌توانید هر دستور چندخطی بالا را در یک خط بنویسید یا از علامت Backtick برای ادامه خط استفاده کنید.

برای امتحان سریع بدون دیتاست پزشکی:

```bash
python scripts/create_synthetic_data.py --output data/raw --per-class 16
python -m cxrnet --config configs/quick_cpu.yaml index
python -m cxrnet --config configs/quick_cpu.yaml split
python -m cxrnet --config configs/quick_cpu.yaml pretrain --epochs 1
python -m cxrnet --config configs/quick_cpu.yaml finetune --domain chest \
  --checkpoint runs/quick_cpu/pretraining/best.pt --epochs 1
```

این تصاویر فقط برای تست نرم‌افزار تولید می‌شوند و هیچ ارزشی به‌عنوان داده پزشکی یا معیار علمی ندارند.

## تفاوت مهم S3

- `s3_fusion: algorithm`: مطابق ادغام جمعی در Algorithm 1 صفحه ۱۰.
- `s3_fusion: diagram`: برداشت مهندسی از شکل ۴ صفحه ۹، شامل Concatenation و Conv و SiLU.
- `attention: none/self/spatial/s3`: برای Ablation Study.

فایل‌های `docs/PAPER_MAPPING.md` و `docs/DESIGN_DECISIONS.md` مرجع دقیق تطبیق هر ماژول با مقاله و توضیح فرض‌ها هستند. برای پژوهش رسمی، صرفاً Accuracy گزارش‌شده کافی نیست و باید آزمون مستقل بیمارمحور، Ablation، چند Seed و معیارهای هر کلاس نیز ارائه شوند.
