"""Enable `python -m cxrnet` without editable installation."""
from cxrnet.cli import main

if __name__ == "__main__":
    main()
