"""One reproducible command-line entrypoint. See README for full workflow."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import torch

from cxrnet.config import load_config
from cxrnet.data.manifest import index_images
from cxrnet.data.splitting import split_manifest
from cxrnet.data.audit import audit_splits
from cxrnet.data.datasets import get_loader
from cxrnet.training.stages import (pretrain_multidomain, finetune_from_pretraining,
                                     train_from_scratch)
from cxrnet.training.checkpoints import load_single
from cxrnet.training.optimizer import make_criterion
from cxrnet.training.engine import evaluate_loader
from cxrnet.evaluation.plots import plot_confusion_matrix
from cxrnet.evaluation.inference import predict_image
from cxrnet.evaluation.ablations import ablate_attention
from cxrnet.evaluation.contrast_sweep import run_contrast_sweep
from cxrnet.evaluation.benchmark import profile_model
from cxrnet.evaluation.explain import save_gradcam_overlay
from cxrnet.model.network import CXRNet
from cxrnet.utils import get_device, seed_everything, write_json


def create_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="cxrnet", description="CXR-Net S3 reproducible research kit")
    p.add_argument("--config", default="configs/default.yaml", help="YAML experiment config")
    p.add_argument("--device", default="auto", help="auto | cpu | cuda | mps")
    p.add_argument("--run-dir", help="Override run directory")
    commands = p.add_subparsers(dest="command", required=True)
    idx = commands.add_parser("index", help="Build dataset manifest")
    idx.add_argument("--patient-map", help="Optional CSV: path,patient_id")
    idx.add_argument("--skip-image-verification", action="store_true")
    commands.add_parser("split", help="Create protected train/val/test partitions")
    audit = commands.add_parser("audit", help="Summarize labels and leakage checks")
    audit.add_argument("--skip-hashes", action="store_true")
    pre = commands.add_parser("pretrain", help="Shared-backbone multi-domain pretraining")
    pre.add_argument("--domains", nargs="+", help="Subset of domains to pretrain")
    pre.add_argument("--epochs", type=int, help="Override pretrain epochs")
    for cmd in ("train", "finetune", "evaluate", "benchmark", "predict", "gradcam", "ablate", "contrast-sweep"):
        sp = commands.add_parser(cmd)
        sp.add_argument("--domain", required=True)
        if cmd in {"train", "finetune", "ablate", "contrast-sweep"}:
            sp.add_argument("--epochs", type=int)
        if cmd in {"finetune", "evaluate", "predict", "gradcam"}:
            sp.add_argument("--checkpoint", required=True)
        if cmd == "finetune":
            sp.add_argument("--reset-head", action="store_true")
        if cmd in {"predict", "gradcam"}:
            sp.add_argument("--image", required=True)
        if cmd == "gradcam":
            sp.add_argument("--output", default="runs/gradcam_overlay.png")
        if cmd == "benchmark":
            sp.add_argument("--batch-size", type=int, default=1)
        if cmd == "ablate":
            sp.add_argument("--modes", nargs="+", default=["none", "self", "spatial", "s3"])
        if cmd == "contrast-sweep":
            sp.add_argument("--methods", nargs="+", default=["equalize", "factor_1.2", "factor_1.4", "factor_1.6"])
    return p


def main(argv: list[str] | None = None) -> None:
    args = create_parser().parse_args(argv)
    cfg = load_config(args.config)
    if args.run_dir:
        cfg.run_dir = args.run_dir
    seed_everything(cfg.seed)
    if args.command == "index":
        manifest = index_images(cfg.data, args.patient_map, not args.skip_image_verification)
        print(f"Indexed {len(manifest)} images: {cfg.data.manifest}")
        return
    if args.command == "split":
        splits = split_manifest(cfg.data, cfg.seed)
        print(f"Split {len(splits)} images: {cfg.data.split_manifest}")
        return
    if args.command == "audit":
        result = audit_splits(cfg.data, check_hashes=not args.skip_hashes)
        write_json(Path(cfg.run_dir) / "data_audit.json", result)
        print(json.dumps(result, indent=2))
        return
    device = get_device(args.device)
    print(f"Device: {device}")
    if args.command == "pretrain":
        if args.epochs is not None:
            cfg.train.pretrain_epochs = args.epochs
        result = pretrain_multidomain(cfg, device, domains=args.domains)
    else:
        domain = args.domain
        if domain not in cfg.data.tasks:
            raise ValueError(f"Unknown domain: {domain}; valid: {list(cfg.data.tasks)}")
        if args.command in {"train", "finetune", "ablate", "contrast-sweep"} and args.epochs is not None:
            cfg.train.epochs = args.epochs
        if args.command == "train":
            result = train_from_scratch(cfg, domain, device)
        elif args.command == "finetune":
            result = finetune_from_pretraining(cfg, domain, args.checkpoint, device,
                                               reset_head=args.reset_head)
        elif args.command == "evaluate":
            model = load_single(args.checkpoint, cfg, domain, device)
            loader = get_loader(cfg, domain, "test")
            criterion = make_criterion(cfg.train, get_loader(cfg, domain, "train").dataset.targets,
                                       len(cfg.data.tasks[domain].classes), device)
            result, p = evaluate_loader(model, loader, criterion, device,
                                        cfg.data.tasks[domain].classes)
            out = Path(cfg.run_dir) / f"evaluation_{domain}"
            write_json(out / "test_metrics.json", result)
            plot_confusion_matrix(result["confusion_matrix"], cfg.data.tasks[domain].classes,
                                  out / "test_confusion_matrix.png")
            frame = loader.dataset.frame.copy()
            frame["predicted_label"] = [cfg.data.tasks[domain].classes[i] for i in p.argmax(1)]
            for i, label in enumerate(cfg.data.tasks[domain].classes):
                frame[f"p_{label}"] = p[:, i]
            frame.to_csv(out / "test_predictions.csv", index=False)
        elif args.command == "predict":
            model = load_single(args.checkpoint, cfg, domain, device)
            result = predict_image(model, cfg, args.image, domain, device)
        elif args.command == "gradcam":
            model = load_single(args.checkpoint, cfg, domain, device)
            index = save_gradcam_overlay(model, args.image, cfg.data, device, args.output)
            result = {"output": args.output, "predicted_class": cfg.data.tasks[domain].classes[index]}
        elif args.command == "benchmark":
            model = CXRNet(cfg.model, len(cfg.data.tasks[domain].classes))
            result = profile_model(model, device, cfg.data.image_size, cfg.data.channels,
                                   batch_size=args.batch_size)
            write_json(Path(cfg.run_dir) / f"benchmark_{domain}.json", result)
        elif args.command == "ablate":
            result = ablate_attention(cfg, domain, device, modes=args.modes)
        elif args.command == "contrast-sweep":
            result = run_contrast_sweep(cfg, domain, device, methods=args.methods)
        else:
            raise RuntimeError(f"Unexpected command {args.command}")
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
