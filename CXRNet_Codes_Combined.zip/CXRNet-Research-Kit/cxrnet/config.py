"""Typed configuration loading, validation, and run reproducibility."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class AugmentationConfig:
    horizontal_flip_probability: float = 0.5
    vertical_flip_probability: float = 0.0
    rotation_degrees: float = 10.0


@dataclass
class SplitConfig:
    train: float = 0.7
    val: float = 0.2
    test: float = 0.1
    respect_existing_splits: bool = True
    require_patient_ids: bool = False
    verify_duplicate_hashes: bool = True
    min_samples_per_class: int = 3


@dataclass
class TaskConfig:
    folder: str
    classes: list[str]


@dataclass
class DataConfig:
    root: str = "data/raw"
    manifest: str = "data/manifests/manifest.csv"
    split_manifest: str = "data/manifests/splits.csv"
    image_size: int = 224
    channels: int = 1
    contrast_factor: float = 1.4
    contrast_method: str = "factor"
    clahe_clip_limit: float = 2.0
    clahe_tile_grid_size: int = 8
    normalize_mean: list[float] = field(default_factory=lambda: [0.5])
    normalize_std: list[float] = field(default_factory=lambda: [0.5])
    augmentation: AugmentationConfig = field(default_factory=AugmentationConfig)
    split: SplitConfig = field(default_factory=SplitConfig)
    tasks: dict[str, TaskConfig] = field(default_factory=dict)


@dataclass
class ModelConfig:
    channels: list[int] = field(default_factory=lambda: [32, 64, 96, 128, 160])
    input_channels: int = 1
    fusion: str = "concat"
    attention: str = "s3"
    s3_fusion: str = "algorithm"
    attention_heads: int = 4
    attention_max_tokens: int = 1024
    spatial_kernel: int = 7
    classifier_hidden: list[int] = field(default_factory=lambda: [256, 128])
    dropout: float = 0.3


@dataclass
class TrainingConfig:
    batch_size: int = 16
    num_workers: int = 0
    epochs: int = 100
    pretrain_epochs: int = 200
    optimizer: str = "adamw"
    learning_rate: float = 3e-4
    weight_decay: float = 1e-4
    label_smoothing: float = 0.0
    class_weighting: str = "none"
    balancing: str = "epoch_balanced"
    mixed_precision: bool = True
    grad_clip_norm: float = 1.0
    early_stopping_patience: int = 20
    monitor: str = "val_loss"
    scheduler: str = "cosine"
    min_learning_rate: float = 1e-6
    persistent_workers: bool = False
    log_every_steps: int = 20


@dataclass
class ExperimentConfig:
    seed: int = 42
    run_dir: str = "runs/default"
    data: DataConfig = field(default_factory=DataConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    train: TrainingConfig = field(default_factory=TrainingConfig)

    def validate(self) -> None:
        s = self.data.split
        if not all(0 < x < 1 for x in (s.train, s.val, s.test)):
            raise ValueError("All split ratios must be strictly between 0 and 1")
        if abs(s.train + s.val + s.test - 1.0) > 1e-8:
            raise ValueError("train + val + test ratios must equal 1")
        if self.data.contrast_method not in {"factor", "none", "equalize", "clahe"}:
            raise ValueError("Unsupported contrast_method")
        if self.data.contrast_factor <= 0 or self.data.clahe_clip_limit <= 0:
            raise ValueError("Contrast factor/CLAHE clip limit must be positive")
        if self.data.clahe_tile_grid_size < 1:
            raise ValueError("CLAHE tile grid size must be positive")
        if self.data.channels not in (1, 3):
            raise ValueError("data.channels must be 1 or 3")
        if self.data.channels != self.model.input_channels:
            raise ValueError("data.channels must match model.input_channels")
        if len(self.data.normalize_mean) != self.data.channels or len(self.data.normalize_std) != self.data.channels:
            raise ValueError("Normalization mean/std lengths must equal data.channels")
        if any(x <= 0 for x in self.data.normalize_std):
            raise ValueError("Normalization std must be positive")
        if self.model.fusion not in {"concat", "sum"}:
            raise ValueError("model.fusion must be 'concat' or 'sum'")
        if self.model.attention not in {"none", "self", "spatial", "s3"}:
            raise ValueError("Unsupported attention ablation")
        if self.model.s3_fusion not in {"algorithm", "diagram"}:
            raise ValueError("Unsupported S3 fusion")
        if len(self.model.channels) < 2 or any(c < 4 for c in self.model.channels):
            raise ValueError("Provide at least two positive stage channel counts (>=4)")
        if self.model.channels[-1] % self.model.attention_heads != 0:
            raise ValueError("Final channel count must be divisible by attention_heads")
        if self.model.spatial_kernel % 2 == 0 or self.model.spatial_kernel < 1:
            raise ValueError("spatial_kernel must be odd positive")
        if any(x < 0 or x > 1 for x in (self.data.augmentation.horizontal_flip_probability,
                                        self.data.augmentation.vertical_flip_probability)):
            raise ValueError("Flip probabilities must be between zero and one")
        if self.train.class_weighting not in {"none", "inverse_frequency"}:
            raise ValueError("Unsupported class weighting")
        if self.train.balancing not in {"epoch_balanced", "none"}:
            raise ValueError("Unsupported train balancing")
        if self.train.balancing != "none" and self.train.class_weighting != "none":
            raise ValueError("Use balanced sampling OR class weights, not both by default")
        if self.train.optimizer not in {"adamw", "sgd"}:
            raise ValueError("Unsupported optimizer")
        if self.train.scheduler not in {"cosine", "none"}:
            raise ValueError("Unsupported scheduler")
        if self.train.monitor not in {"val_loss", "val_accuracy", "val_macro_f1"}:
            raise ValueError("Unsupported monitor")
        for name, task in self.data.tasks.items():
            if not task.classes or len(set(task.classes)) != len(task.classes):
                raise ValueError(f"Task {name} must have unique nonempty classes")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def deep_update(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    """Merge nested YAML dictionaries, rejecting unknown keys (avoid silent config typos)."""
    for k, v in overlay.items():
        if k not in base:
            raise ValueError(f"Unknown config key: {k}")
        if isinstance(base[k], dict) and isinstance(v, dict):
            deep_update(base[k], v)
        else:
            base[k] = v
    return base


def load_config(path: str | Path, overrides: dict[str, Any] | None = None) -> ExperimentConfig:
    data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Config YAML must be a mapping")
    if overrides:
        data = deep_update(data, overrides)
    d = data["data"]
    return_config = ExperimentConfig(
        seed=data.get("seed", 42), run_dir=data.get("run_dir", "runs/default"),
        data=DataConfig(
            **{k: v for k, v in d.items() if k not in {"augmentation", "split", "tasks"}},
            augmentation=AugmentationConfig(**d.get("augmentation", {})),
            split=SplitConfig(**d.get("split", {})),
            tasks={k: TaskConfig(**v) for k, v in d.get("tasks", {}).items()},
        ),
        model=ModelConfig(**data.get("model", {})),
        train=TrainingConfig(**data.get("train", {})),
    )
    return_config.validate()
    return return_config


def save_config(config: ExperimentConfig, directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "resolved_config.yaml").write_text(
        yaml.safe_dump(config.to_dict(), sort_keys=False), encoding="utf-8"
    )
