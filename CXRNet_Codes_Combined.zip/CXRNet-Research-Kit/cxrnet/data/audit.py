"""Preflight checks: partitions, patient identity, class balance, duplicate bytes."""
from __future__ import annotations
from pathlib import Path
import pandas as pd
from cxrnet.config import DataConfig
from cxrnet.data.manifest import load_manifest
from cxrnet.data.splitting import (assert_no_patient_overlap, assert_no_path_overlap,
                                    assert_no_file_hash_overlap)
from cxrnet.utils import write_json


def audit_splits(config: DataConfig, *, check_hashes: bool = True) -> dict:
    df = load_manifest(config.split_manifest)
    if "split" not in df.columns:
        raise ValueError("No split column; run 'cxrnet split' first")
    assert_no_path_overlap(df)
    assert_no_patient_overlap(df)
    if check_hashes:
        assert_no_file_hash_overlap(df, Path(config.root))
    table = (df.groupby(["domain", "label", "split"]).size()
             .rename("count").reset_index().to_dict(orient="records"))
    missing_ids = int(df.patient_id.eq("").sum())
    return {"n_images": int(len(df)), "n_unknown_patient_ids": missing_ids,
            "patient_level_safety_certified": missing_ids == 0,
            "verified_duplicate_bytes": bool(check_hashes),
            "counts": table,
            "warnings": (["Patient-level independence NOT demonstrated; supply patient IDs."
                          ] if missing_ids else []) + [
                            "Identical image files checked; near-duplicates need independent audit.",
                            "Site/device independent external test is NOT established by these checks.",
                          ]}
