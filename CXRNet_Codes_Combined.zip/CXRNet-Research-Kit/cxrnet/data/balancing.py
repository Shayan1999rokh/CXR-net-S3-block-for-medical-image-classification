"""Exactly balanced per-class train epochs, sampling minority examples with replacement.

All replacements are transformed independently by stochastic train-time augmentation;
validation and test splits are NEVER balanced or augmented. Not equivalent to
publishing '9000 test-inclusive augmented images' (which risks leakage).
"""
from __future__ import annotations
from collections import defaultdict
import torch
from torch.utils.data import Sampler


class BalancedEpochSampler(Sampler[int]):
    def __init__(self, targets: list[int], seed: int = 42, target_per_class: int | None = None):
        bins: dict[int, list[int]] = defaultdict(list)
        for i, target in enumerate(targets):
            bins[int(target)].append(i)
        if not bins:
            raise ValueError("No labels")
        self.bins = dict(bins)
        self.max_per_class = target_per_class or max(len(items) for items in self.bins.values())
        if self.max_per_class < 1:
            raise ValueError("Target per class must be >= 1")
        self.seed = seed
        self.epoch = 0

    def __len__(self):
        return self.max_per_class * len(self.bins)

    def __iter__(self):
        generator = torch.Generator().manual_seed(self.seed + self.epoch)
        self.epoch += 1
        output = []
        for class_id in sorted(self.bins):
            indices = self.bins[class_id]
            if len(indices) >= self.max_per_class:
                sampled = torch.randperm(len(indices), generator=generator)[:self.max_per_class]
            else:
                sampled = torch.randint(len(indices), (self.max_per_class,), generator=generator)
            output.extend(indices[i] for i in sampled.tolist())
        random_order = torch.randperm(len(output), generator=generator)
        return (output[i] for i in random_order.tolist())
