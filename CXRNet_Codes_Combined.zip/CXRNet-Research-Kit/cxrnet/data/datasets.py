"""Label-controlled, partitioned X-ray image datasets."""
from __future__ import annotations

from pathlib import Path
import pandas as pd
from PIL import Image, ImageOps
from torch.utils.data import DataLoader, Dataset
import torch

from cxrnet.config import DataConfig, ExperimentConfig
from cxrnet.data.manifest import load_manifest
from cxrnet.data.splitting import assert_no_path_overlap, assert_no_patient_overlap
from cxrnet.data.transforms import build_transforms
from cxrnet.data.balancing import BalancedEpochSampler
from cxrnet.utils import seed_worker


class XRayDataset(Dataset):
    def __init__(self, frame: pd.DataFrame, *, root: Path, classes: list[str],
                 channels: int, transform=None):
        self.frame = frame.reset_index(drop=True)
        self.root = root.resolve()
        self.classes = list(classes)
        self.class_to_index = {name: i for i, name in enumerate(classes)}
        self.channels = channels
        self.transform = transform
        unknown = set(self.frame.label) - set(classes)
        if unknown:
            raise ValueError(f"Unknown dataset labels: {unknown}")
        self.targets = [self.class_to_index[x] for x in self.frame.label]

    def __len__(self) -> int:
        return len(self.frame)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, int]:
        row = self.frame.iloc[idx]
        path = (self.root / row.path).resolve()
        if not path.is_relative_to(self.root):
            raise ValueError(f"Image path escapes data root: {path}")
        with Image.open(path) as im:
            image = ImageOps.exif_transpose(im).convert("L" if self.channels == 1 else "RGB")
        if self.transform is not None:
            image = self.transform(image)
        return image, self.class_to_index[row.label]


def get_dataset(config: DataConfig, domain: str, split: str) -> XRayDataset:
    if domain not in config.tasks:
        raise ValueError(f"Unknown task {domain!r}; available={list(config.tasks)}")
    if split not in {"train", "val", "test"}:
        raise ValueError(f"Invalid split {split}")
    frame = load_manifest(config.split_manifest)
    if "split" not in frame.columns:
        raise ValueError("Run split step first: no 'split' column")
    assert_no_path_overlap(frame)
    assert_no_patient_overlap(frame)
    selected = frame[(frame.domain == domain) & (frame.split == split)]
    if selected.empty:
        raise ValueError(f"No images for domain={domain}, split={split}")
    return XRayDataset(selected, root=Path(config.root), classes=config.tasks[domain].classes,
                       channels=config.channels,
                       transform=build_transforms(config, train=(split == "train")))


def get_loader(config: ExperimentConfig, domain: str, split: str,
               *, batch_size: int | None = None) -> DataLoader:
    ds = get_dataset(config.data, domain, split)
    train = split == "train"
    gen = torch.Generator().manual_seed(config.seed)
    sampler = (BalancedEpochSampler(ds.targets, seed=config.seed)
               if train and config.train.balancing == "epoch_balanced" else None)
    return DataLoader(
        ds,
        batch_size=batch_size or config.train.batch_size,
        shuffle=train and sampler is None,
        sampler=sampler,
        drop_last=False,
        num_workers=config.train.num_workers,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=config.train.persistent_workers and config.train.num_workers > 0,
        worker_init_fn=seed_worker,
        generator=gen,
    )
