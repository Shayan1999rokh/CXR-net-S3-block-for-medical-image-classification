"""Dataset indexing, label validation, and optional patient identity metadata.

Supported layouts:
    root/TASK/CLASS/**/image.png
    root/TASK/{train,val,test}/CLASS/**/image.png
Optional patient_ids.csv: columns [path, patient_id], with path relative to root.
No patient ID is fabricated: missing IDs are represented by an empty string.
"""
from __future__ import annotations

from pathlib import Path
import pandas as pd
from PIL import Image
from cxrnet.config import DataConfig

SUPPORTED_SUFFIXES = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
SOURCE_SPLITS = {"train", "val", "valid", "validation", "test"}
REQUIRED_COLUMNS = {"path", "domain", "label", "patient_id", "source_split"}


def index_images(config: DataConfig, patient_map_csv: str | None = None,
                 verify_readable: bool = True) -> pd.DataFrame:
    root = Path(config.root).resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"Data root missing: {root}")
    ids: dict[str, str] = {}
    if patient_map_csv:
        mapping = pd.read_csv(patient_map_csv, dtype=str).fillna("")
        if not {"path", "patient_id"}.issubset(mapping.columns):
            raise ValueError("patient map must have path and patient_id columns")
        if mapping.path.duplicated().any():
            raise ValueError("Duplicate paths in patient map")
        ids = dict(zip(mapping.path.map(lambda x: Path(x).as_posix()), mapping.patient_id))
    records: list[dict] = []
    for domain, task in config.tasks.items():
        folder = root / task.folder
        if not folder.is_dir():
            raise FileNotFoundError(f"Missing task folder: {folder}")
        valid_labels = set(task.classes)
        for f in sorted(folder.rglob("*")):
            if not f.is_file() or f.suffix.lower() not in SUPPORTED_SUFFIXES:
                continue
            rel = f.relative_to(root).as_posix()
            parts = f.relative_to(folder).parts
            source_split = ""
            if len(parts) >= 3 and parts[0].lower() in SOURCE_SPLITS:
                source_split = {"valid": "val", "validation": "val"}.get(parts[0].lower(), parts[0].lower())
                label = parts[1]
            elif len(parts) >= 2:
                label = parts[0]
            else:
                raise ValueError(f"Cannot find CLASS directory for {f}")
            if label not in valid_labels:
                raise ValueError(f"Unexpected label {label!r} for {domain}: {f}")
            if verify_readable:
                try:
                    with Image.open(f) as im:
                        im.verify()
                except Exception as e:
                    raise ValueError(f"Unreadable/corrupted image {f}: {e}") from e
            records.append({"path": rel, "domain": domain, "label": label,
                            "patient_id": ids.get(rel, ""), "source_split": source_split})
    if not records:
        raise ValueError(f"No images found under {root}")
    df = pd.DataFrame(records, columns=sorted(REQUIRED_COLUMNS))
    if df.path.duplicated().any():
        raise ValueError("Duplicate image paths found")
    if config.split.require_patient_ids and (df.patient_id == "").any():
        raise ValueError("Patient-level split REQUIRED but patient IDs are missing")
    for domain, group in df.groupby("domain"):
        expected = set(config.tasks[domain].classes)
        actual = set(group.label.unique())
        if actual != expected:
            raise ValueError(f"Domain {domain}: labels missing: {sorted(expected-actual)}")
    out = Path(config.manifest)
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    return df


def load_manifest(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path, dtype=str).fillna("")
    if not REQUIRED_COLUMNS.issubset(df.columns):
        raise ValueError(f"Manifest must contain: {sorted(REQUIRED_COLUMNS)}")
    if df.path.duplicated().any():
        raise ValueError("Manifest contains duplicate image paths")
    return df
