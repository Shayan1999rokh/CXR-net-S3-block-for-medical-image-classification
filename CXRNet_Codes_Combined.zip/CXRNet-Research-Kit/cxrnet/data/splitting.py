"""Leakage-conscious 70/20/10 splitting BEFORE augmentation.

Supports group-level stratification and multi-label-per-patient group folds.
Groups are never shared across train/val/test; actual image fractions can be
approximate when patient groups have unequal size.
"""
from __future__ import annotations

from pathlib import Path
from collections import defaultdict
import warnings

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedShuffleSplit, StratifiedGroupKFold

from cxrnet.config import DataConfig
from cxrnet.data.manifest import load_manifest
from cxrnet.utils import file_sha256


def _unseeded_group_aware_split(df: pd.DataFrame, seed: int,
                                config: DataConfig) -> pd.Series:
    """Split patient groups, not image rows, preserving approximate class balance.

    If each patient has one label, stratify unique PATIENTS directly. For
    multi-label-per-patient groups, search reproducible GroupKFold partitions,
    accepting the first partition where every class is present in every fold.
    """
    labels_by_group = df.groupby("patient_id")["label"].nunique()
    if len(labels_by_group) < 10:
        raise ValueError("Group splitting requires >=10 distinct patient IDs per domain")
    if labels_by_group.max() == 1:
        grouped = df.groupby("patient_id", sort=True).first().reset_index()
        labels = grouped.label.to_numpy()
        group_ids = grouped.patient_id.to_numpy()
        first = StratifiedShuffleSplit(n_splits=1, test_size=config.split.test,
                                       random_state=seed)
        remaining, test = next(first.split(np.zeros(len(grouped)), labels))
        second = StratifiedShuffleSplit(
            n_splits=1, test_size=config.split.val / (config.split.train + config.split.val),
            random_state=seed + 1)
        train_local, val_local = next(second.split(np.zeros(len(remaining)), labels[remaining]))
        assignment = {group_ids[i]: "train" for i in remaining[train_local]}
        assignment.update({group_ids[i]: "val" for i in remaining[val_local]})
        assignment.update({group_ids[i]: "test" for i in test})
        return df.patient_id.map(assignment)

    labels = df.label.to_numpy()
    groups = df.patient_id.to_numpy()
    all_labels = set(df.label)
    for attempt in range(16):
        gkf = StratifiedGroupKFold(n_splits=10, shuffle=True,
                                    random_state=seed + attempt)
        assigned = pd.Series(index=df.index, dtype="object")
        for fold, (_, indices) in enumerate(gkf.split(np.zeros(len(df)), labels, groups)):
            split = "test" if fold == 0 else "val" if fold in (1, 2) else "train"
            assigned.iloc[indices] = split
        if all(set(df.loc[assigned == split, "label"]) == all_labels
               for split in ("train", "val", "test")):
            return assigned
    raise ValueError("Could not form group-disjoint partitions containing every class; "
                     "supply more patient groups or a curated patient-level split")


def _stratified_split(df: pd.DataFrame, config: DataConfig, seed: int) -> pd.Series:
    labels = df.label.to_numpy()
    first = StratifiedShuffleSplit(n_splits=1, test_size=config.split.test, random_state=seed)
    rest_idx, test_idx = next(first.split(np.zeros(len(df)), labels))
    second = StratifiedShuffleSplit(n_splits=1,
                                    test_size=config.split.val / (config.split.train + config.split.val),
                                    random_state=seed + 1)
    train_local, val_local = next(second.split(np.zeros(len(rest_idx)), labels[rest_idx]))
    split = np.full(len(df), "", dtype=object)
    split[test_idx] = "test"
    split[rest_idx[train_local]] = "train"
    split[rest_idx[val_local]] = "val"
    return pd.Series(split, index=df.index)


def split_manifest(config: DataConfig, seed: int) -> pd.DataFrame:
    df = load_manifest(config.manifest)
    out: list[pd.DataFrame] = []
    for domain, sub in df.groupby("domain", sort=True):
        sub = sub.copy().reset_index(drop=True)
        if any((sub.label == label).sum() < config.split.min_samples_per_class
               for label in config.tasks[domain].classes):
            raise ValueError(f"Not enough samples per class for {domain}")
        existing = sub.source_split.ne("")
        if existing.any() and not existing.all():
            raise ValueError(f"Mixed pre-split and unsplit paths in {domain}")
        if existing.all() and config.split.respect_existing_splits:
            sub["split"] = sub.source_split
            if set(sub.split.unique()) != {"train", "val", "test"}:
                raise ValueError(f"Incomplete source splits in {domain}; expected train/val/test")
        elif sub.patient_id.ne("").all():
            sub["split"] = _unseeded_group_aware_split(sub, seed, config)
        else:
            if config.split.require_patient_ids:
                raise ValueError(f"Missing patient IDs in {domain}")
            warnings.warn(f"No complete patient IDs in {domain}: image-level split is NOT patient-safe",
                          UserWarning, stacklevel=2)
            sub["split"] = _stratified_split(sub, config, seed)
        for label in config.tasks[domain].classes:
            for split in ("train", "val", "test"):
                if not ((sub.label == label) & (sub.split == split)).any():
                    raise ValueError(f"Empty {domain}/{label}/{split} partition")
        out.append(sub)
    result = pd.concat(out, ignore_index=True)
    assert_no_patient_overlap(result)
    assert_no_path_overlap(result)
    if config.split.verify_duplicate_hashes:
        assert_no_file_hash_overlap(result, Path(config.root))
    path = Path(config.split_manifest)
    path.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(path, index=False)
    return result


def assert_no_path_overlap(df: pd.DataFrame) -> None:
    if df.path.duplicated().any():
        raise ValueError("Same image path occurs multiple times in manifest")
    if not set(df.split.unique()).issubset({"train", "val", "test"}):
        raise ValueError("Invalid split name")


def assert_no_patient_overlap(df: pd.DataFrame) -> None:
    complete = df[df.patient_id.ne("")]
    # Same ID across domains is assumed to mean same person; conservative validation.
    split_counts = complete.groupby("patient_id")["split"].nunique()
    bad = split_counts[split_counts > 1]
    if not bad.empty:
        raise ValueError(f"Patient IDs span partitions: {bad.index[:10].tolist()}")


def assert_no_file_hash_overlap(df: pd.DataFrame, root: Path) -> None:
    """Catch byte-identical images across train/val/test; not perceptual near-duplicates."""
    digest_to_splits: dict[str, set[str]] = defaultdict(set)
    for row in df.itertuples(index=False):
        digest_to_splits[file_sha256(root / row.path)].add(row.split)
    bad = sum(len(splits) > 1 for splits in digest_to_splits.values())
    if bad:
        raise ValueError(f"Found {bad} byte-identical image group(s) across partitions")
