"""Deterministic enhancement and train-only geometric augmentation.

The source paper compares histogram equalization, CLAHE and 20/40/60% contrast.
This module provides all three methods, but the original "40%" equation is
unspecified: PIL `enhance(1.4)` is an explicit engineering interpretation.
"""
from __future__ import annotations

from PIL import Image, ImageEnhance, ImageOps
import numpy as np
from torchvision import transforms as T
from cxrnet.config import DataConfig


class ContrastTransform:
    def __init__(self, method: str, *, factor: float = 1.4,
                 clahe_clip_limit: float = 2.0, clahe_tile_grid_size: int = 8):
        if method not in {"none", "factor", "equalize", "clahe"}:
            raise ValueError(f"Unsupported contrast enhancement method: {method}")
        if factor <= 0 or clahe_clip_limit <= 0 or clahe_tile_grid_size < 1:
            raise ValueError("Invalid contrast parameters")
        self.method = method
        self.factor = factor
        self.clahe_clip_limit = clahe_clip_limit
        self.clahe_tile_grid_size = clahe_tile_grid_size

    def __call__(self, image: Image.Image) -> Image.Image:
        if self.method == "none":
            return image
        if self.method == "factor":
            return ImageEnhance.Contrast(image).enhance(self.factor)
        if self.method == "equalize":
            return ImageOps.equalize(image)
        try:
            import cv2
        except ImportError as e:
            raise ImportError("CLAHE requires pip install -e '.[clahe]' (opencv-python-headless)") from e
        if image.mode not in ("L", "RGB"):
            raise ValueError("CLAHE requires grayscale or RGB PIL image")
        clahe = cv2.createCLAHE(clipLimit=self.clahe_clip_limit,
                                tileGridSize=(self.clahe_tile_grid_size, self.clahe_tile_grid_size))
        array = np.asarray(image)
        if image.mode == "L":
            return Image.fromarray(clahe.apply(array))
        # Apply luminance-only CLAHE for RGB; do not distort chromaticity channels.
        lab = cv2.cvtColor(array, cv2.COLOR_RGB2LAB)
        lab[:, :, 0] = clahe.apply(lab[:, :, 0])
        return Image.fromarray(cv2.cvtColor(lab, cv2.COLOR_LAB2RGB))


def build_transforms(config: DataConfig, train: bool) -> T.Compose:
    """Resize -> contrast -> (train-only geometry) -> tensor -> normalization."""
    operations: list = [T.Resize((config.image_size, config.image_size),
                                 interpolation=T.InterpolationMode.BILINEAR),
                         ContrastTransform(config.contrast_method,
                                           factor=config.contrast_factor,
                                           clahe_clip_limit=config.clahe_clip_limit,
                                           clahe_tile_grid_size=config.clahe_tile_grid_size)]
    if train:
        aug = config.augmentation
        if aug.horizontal_flip_probability:
            operations.append(T.RandomHorizontalFlip(aug.horizontal_flip_probability))
        if aug.vertical_flip_probability:
            operations.append(T.RandomVerticalFlip(aug.vertical_flip_probability))
        if aug.rotation_degrees:
            operations.append(T.RandomRotation(aug.rotation_degrees,
                                               interpolation=T.InterpolationMode.BILINEAR,
                                               fill=0))
    operations.extend([T.ToTensor(), T.Normalize(config.normalize_mean, config.normalize_std)])
    return T.Compose(operations)
