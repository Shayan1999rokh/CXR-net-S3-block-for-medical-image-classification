"""Controlled attention ablations selected exclusively on validation performance."""
from __future__ import annotations
from copy import deepcopy
from pathlib import Path
import pandas as pd
import torch
from cxrnet.config import ExperimentConfig
from cxrnet.model.network import CXRNet
from cxrnet.training.stages import _run_training_single
from cxrnet.utils import seed_everything, write_json


def ablate_attention(config: ExperimentConfig, domain: str, device: torch.device,
                     modes: list[str] | None = None) -> list[dict]:
    modes = modes or ["none", "self", "spatial", "s3"]
    if len(set(modes)) != len(modes) or not set(modes).issubset({"none", "self", "spatial", "s3"}):
        raise ValueError(f"Invalid ablation modes: {modes}")
    results: list[dict] = []
    output_dir = Path(config.run_dir) / f"ablation_{domain}"
    for mode in modes:
        cfg = deepcopy(config)
        cfg.model.attention = mode
        seed_everything(cfg.seed)
        model = CXRNet(cfg.model, len(cfg.data.tasks[domain].classes))
        result = _run_training_single(cfg, domain, device, initialized=model,
                    run_directory=output_dir / mode, test_at_end=False)
        results.append({"mode": mode, "best_validation_score": result["best_val_score"],
                        "best_epoch": result["best_epoch"],
                        "checkpoint": result["best_checkpoint"]})
    output_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(results).to_csv(output_dir / "validation_comparison.csv", index=False)
    write_json(output_dir / "validation_comparison.json", results)
    return results
