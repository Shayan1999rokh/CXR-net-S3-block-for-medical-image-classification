"""Reproducible model resource profiling (latency is hardware-specific)."""
from __future__ import annotations
import time
import torch


def profile_model(model: torch.nn.Module, device: torch.device,
                  image_size: int, channels: int = 1, batch_size: int = 1,
                  warmup: int = 10, iterations: int = 30) -> dict:
    model.eval().to(device)
    x = torch.randn(batch_size, channels, image_size, image_size, device=device)
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    with torch.inference_mode():
        for _ in range(warmup):
            model(x)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        start = time.perf_counter()
        for _ in range(iterations):
            model(x)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        duration = time.perf_counter() - start
    return {"parameters_total": int(total), "parameters_trainable": int(trainable),
            "model_size_mb_fp32": total * 4 / 1e6,
            "mean_batch_latency_ms": 1000 * duration / iterations,
            "mean_image_latency_ms": 1000 * duration / (iterations * batch_size),
            "throughput_images_per_second": iterations * batch_size / duration,
            "device": str(device), "image_size": image_size, "batch_size": batch_size,
            "peak_cuda_allocated_mb": (torch.cuda.max_memory_allocated(device) / 1e6
                                      if device.type == "cuda" else None),
            "note": "Latency depends on hardware, warmup, batch size and PyTorch version; not paper-specified."}
