"""Controlled Table 2-style enhancement comparisons on VALIDATION only.

Method selection on TEST was described in the article; this module instead
protects an independent test split for final evaluation.
"""
from __future__ import annotations
from copy import deepcopy
from pathlib import Path
import pandas as pd
import torch
from cxrnet.config import ExperimentConfig
from cxrnet.model.network import CXRNet
from cxrnet.training.stages import _run_training_single
from cxrnet.utils import seed_everything, write_json


SUPPORTED_ENHANCEMENTS = {"none", "equalize", "clahe", "factor_1.2", "factor_1.4", "factor_1.6"}


def run_contrast_sweep(config: ExperimentConfig, domain: str, device: torch.device,
                       methods: list[str] | None = None) -> list[dict]:
    methods = methods or ["equalize", "factor_1.2", "factor_1.4", "factor_1.6"]
    if not methods or not set(methods).issubset(SUPPORTED_ENHANCEMENTS):
        raise ValueError(f"Invalid methods {methods}; valid={sorted(SUPPORTED_ENHANCEMENTS)}")
    records = []
    base = Path(config.run_dir) / f"contrast_sweep_{domain}"
    for method in methods:
        cfg = deepcopy(config)
        if method.startswith("factor_"):
            cfg.data.contrast_method = "factor"
            cfg.data.contrast_factor = float(method.split("_", 1)[1])
        else:
            cfg.data.contrast_method = method
        cfg.validate()
        seed_everything(cfg.seed)
        model = CXRNet(cfg.model, len(cfg.data.tasks[domain].classes))
        output = _run_training_single(cfg, domain, device, initialized=model,
                         run_directory=base / method, test_at_end=False)
        records.append({"method": method, "best_validation_score": output["best_val_score"],
                        "best_epoch": output["best_epoch"],
                        "checkpoint": output["best_checkpoint"]})
    base.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(records).to_csv(base / "validation_comparison.csv", index=False)
    write_json(base / "validation_comparison.json", records)
    return records
