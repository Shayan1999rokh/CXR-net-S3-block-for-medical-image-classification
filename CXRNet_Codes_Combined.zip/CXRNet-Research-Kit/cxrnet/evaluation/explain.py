"""Grad-CAM implementation with explicit caveat: attention != causal explanation."""
from __future__ import annotations
from pathlib import Path
import numpy as np
from PIL import Image
import torch
import torch.nn.functional as F

from cxrnet.data.transforms import build_transforms
from cxrnet.config import DataConfig


class GradCAM:
    """Grad-CAM using feature activation and its gradients at the specified module.

    Instantiate target_layer=model.backbone.stages[-1] for default architecture.
    Hooks are removed in a finally block. Not a clinical localization validator.
    """
    def __init__(self, model: torch.nn.Module, target_layer: torch.nn.Module):
        self.model = model
        self.activations = None
        self.gradients = None
        self.forward_hook = target_layer.register_forward_hook(self._save_activations)
        self.backward_hook = target_layer.register_full_backward_hook(self._save_gradients)

    def _save_activations(self, module, inputs, output):
        self.activations = output

    def _save_gradients(self, module, grad_input, grad_output):
        self.gradients = grad_output[0]

    def close(self) -> None:
        self.forward_hook.remove()
        self.backward_hook.remove()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __call__(self, x: torch.Tensor, class_index: int | None = None):
        self.model.eval()
        with torch.enable_grad():
            self.model.zero_grad(set_to_none=True)
            scores = self.model(x)
            if class_index is None:
                class_index = int(scores.argmax(dim=1)[0])
            scores[:, class_index].sum().backward()
            if self.gradients is None or self.activations is None:
                raise RuntimeError("Grad-CAM hooks did not capture gradients/activations")
            weight = self.gradients.mean(dim=(2, 3), keepdim=True)
            cam = F.relu((self.activations * weight).sum(dim=1, keepdim=True))
            cam = F.interpolate(cam, size=x.shape[-2:], mode="bilinear", align_corners=False)
            cam_min = cam.flatten(1).min(dim=1).values[:, None, None, None]
            cam_max = cam.flatten(1).max(dim=1).values[:, None, None, None]
            cam = (cam - cam_min) / (cam_max - cam_min).clamp_min(1e-8)
        return cam.detach(), class_index


def save_gradcam_overlay(model, image_path: str | Path, config: DataConfig,
                         device: torch.device, output_path: str | Path,
                         class_index: int | None = None) -> int:
    with Image.open(image_path) as image:
        image = image.convert("L" if config.channels == 1 else "RGB")
        original = image.resize((config.image_size, config.image_size)).convert("RGB")
        tensor = build_transforms(config, train=False)(image).unsqueeze(0).to(device)
    with GradCAM(model, model.backbone.stages[-1]) as cam_extractor:
        cam, index = cam_extractor(tensor, class_index)
    cam_array = (cam.squeeze().cpu().numpy() * 255).astype(np.uint8)
    color_map = np.asarray(Image.fromarray(cam_array).convert("RGB"), dtype=np.float32)
    # Simple red heatmap: deterministic and avoids external opencv dependency.
    color_map[:, :, 0] = cam_array
    color_map[:, :, 1] = np.zeros_like(cam_array)
    color_map[:, :, 2] = 0
    overlay = (0.65 * np.asarray(original, dtype=np.float32) + 0.35 * color_map).clip(0, 255)
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(overlay.astype(np.uint8)).save(out)
    return index
