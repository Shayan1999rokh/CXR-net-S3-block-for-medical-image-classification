"""Standalone predictions and calibrated-probability caveat for clinical research."""
from __future__ import annotations
from pathlib import Path
from PIL import Image, ImageOps
import torch

from cxrnet.config import ExperimentConfig
from cxrnet.data.transforms import build_transforms


@torch.inference_mode()
def predict_image(model, config: ExperimentConfig, image_path: str | Path,
                  domain: str, device: torch.device) -> dict:
    model.eval().to(device)
    with Image.open(image_path) as im:
        image = ImageOps.exif_transpose(im).convert("L" if config.data.channels == 1 else "RGB")
    x = build_transforms(config.data, train=False)(image).unsqueeze(0).to(device)
    scores = model(x)
    probabilities = torch.softmax(scores, dim=1)[0].float().cpu().tolist()
    names = config.data.tasks[domain].classes
    i = int(max(range(len(names)), key=lambda j: probabilities[j]))
    return {"predicted_class": names[i], "confidence_uncalibrated": probabilities[i],
            "all_probabilities_uncalibrated": dict(zip(names, probabilities)),
            "warning": "Research-only; not a medical diagnostic decision or a calibrated probability."}
