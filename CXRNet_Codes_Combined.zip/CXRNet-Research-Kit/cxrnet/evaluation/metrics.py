"""Multiclass medical classification metrics, including per-class safety signals.

All metrics are computed from accumulated *sample-level* predictions, not
averages over batches. Undefined AUCs are returned as None, never silently 0.
"""
from __future__ import annotations

import math
import numpy as np
from sklearn.metrics import (accuracy_score, confusion_matrix, precision_recall_fscore_support,
                             roc_auc_score, balanced_accuracy_score, log_loss)


def wilson_interval(k: int, n: int, z: float = 1.959963984540054) -> dict | None:
    """Approximate 95% binomial CI for independent observations only."""
    if not n:
        return None
    p = k / n
    denom = 1.0 + z * z / n
    center = (p + z * z / (2.0 * n)) / denom
    radius = z / denom * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return {"lower": max(0.0, center - radius), "upper": min(1.0, center + radius),
            "method": "Wilson score 95%; image independence assumed"}


def expected_calibration_error(y_true: np.ndarray, probabilities: np.ndarray,
                               bins: int = 15) -> float:
    if not len(y_true):
        raise ValueError("Empty predictions")
    confidence = probabilities.max(axis=1)
    predicted = probabilities.argmax(axis=1)
    correctness = (predicted == y_true).astype(float)
    ece = 0.0
    for i in range(bins):
        lower, upper = i / bins, (i + 1) / bins
        included = (confidence >= lower) & (confidence <= upper if i == bins - 1 else confidence < upper)
        if included.any():
            ece += float(included.mean() * abs(correctness[included].mean() - confidence[included].mean()))
    return ece


def compute_metrics(y_true: np.ndarray | list, probabilities: np.ndarray,
                    class_names: list[str]) -> dict:
    y = np.asarray(y_true, dtype=np.int64)
    p = np.asarray(probabilities, dtype=np.float64)
    n_classes = len(class_names)
    if y.ndim != 1 or p.shape != (len(y), n_classes) or len(y) == 0:
        raise ValueError("Expected nonempty [N] labels and [N,C] probabilities")
    if not np.isfinite(p).all() or not np.allclose(p.sum(axis=1), 1, atol=1e-4):
        raise ValueError("Probabilities must be finite and sum to one")
    # sklearn 1.8 requires row sums within a stricter tolerance for multiclass ROC-AUC.
    p = p / p.sum(axis=1, keepdims=True)
    predicted = p.argmax(axis=1)
    indices = np.arange(n_classes)
    prec, rec, f1, support = precision_recall_fscore_support(
        y, predicted, labels=indices, average=None, zero_division=0
    )
    cm = confusion_matrix(y, predicted, labels=indices)
    per_class = {}
    for i, label in enumerate(class_names):
        tp = int(cm[i, i]); fn = int(cm[i, :].sum() - tp)
        fp = int(cm[:, i].sum() - tp)
        tn = int(cm.sum() - tp - fn - fp)
        specificity = float(tn / (tn + fp)) if tn + fp else None
        per_class[label] = {
            "precision": float(prec[i]), "recall_sensitivity": float(rec[i]),
            "specificity": specificity, "f1": float(f1[i]), "support": int(support[i]),
            "tp": tp, "fp": fp, "fn": fn, "tn": tn,
            "sensitivity_ci95": wilson_interval(tp, tp + fn),
        }
    metrics = {
        "n_samples": int(len(y)), "accuracy": float(accuracy_score(y, predicted)),
        "accuracy_ci95": wilson_interval(int((y == predicted).sum()), len(y)),
        "balanced_accuracy": float(balanced_accuracy_score(y, predicted)),
        "macro_precision": float(np.mean(prec)), "macro_recall": float(np.mean(rec)),
        "macro_f1": float(np.mean(f1)),
        "weighted_f1": float(np.average(f1, weights=support)) if support.sum() else 0.0,
        "cross_entropy": float(log_loss(y, np.clip(p, 1e-12, 1), labels=indices)),
        "expected_calibration_error": float(expected_calibration_error(y, p)),
        "confusion_matrix": cm.tolist(), "class_names": list(class_names),
        "per_class": per_class,
    }
    try:
        if n_classes == 2 and len(np.unique(y)) == 2:
            metrics["roc_auc"] = float(roc_auc_score(y, p[:, 1]))
        elif n_classes > 2 and len(np.unique(y)) == n_classes:
            metrics["roc_auc"] = float(roc_auc_score(y, p, multi_class="ovr", average="macro"))
        else:
            metrics["roc_auc"] = None
    except ValueError:
        metrics["roc_auc"] = None
    return metrics
