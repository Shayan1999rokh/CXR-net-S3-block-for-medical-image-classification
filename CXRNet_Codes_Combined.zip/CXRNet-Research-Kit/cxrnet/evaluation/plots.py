"""Self-contained evaluation plots suitable for paper supplements."""
from __future__ import annotations

from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def plot_confusion_matrix(matrix: list[list[int]], labels: list[str], path: str | Path) -> None:
    cm = np.array(matrix)
    fig, ax = plt.subplots(figsize=(max(6, len(labels)*1.4), 5))
    im = ax.imshow(cm, cmap="Blues")
    fig.colorbar(im, ax=ax)
    ax.set(xticks=np.arange(len(labels)), yticks=np.arange(len(labels)),
           xticklabels=labels, yticklabels=labels, xlabel="Predicted", ylabel="True",
           title="Confusion matrix (test only)")
    plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center")
    fig.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=180)
    plt.close(fig)


def plot_training_history(history: list[dict], path: str | Path) -> None:
    if not history:
        return
    epochs = [int(x["epoch"]) for x in history]
    train = [x["train_loss"] for x in history]
    val = [x["val_loss"] for x in history]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(epochs, train, label="Train loss")
    ax.plot(epochs, val, label="Validation loss")
    ax.set(xlabel="Epoch", ylabel="Cross-entropy", title="Optimization history")
    ax.legend()
    fig.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=180)
    plt.close(fig)
