"""S3 attention, aligned explicitly to Algorithm 1 and optionally to Figure 4.

Algorithm 1 uses scaled dot-product Q/K/V attention + max/avg spatial mask
and adds branch outputs. Figure 4 depicts concat->Conv->SiLU; this alternative
is exposed as s3_fusion='diagram'. Figure 4 branch labels are inconsistent
with the algorithm and descriptive text; we follow *operations* instead.
"""
from __future__ import annotations
import math

import torch
from torch import nn
import torch.nn.functional as F


class SpatialAttention(nn.Module):
    """CBAM-style channel-pooled 2D attention (reweight without additive residual)."""
    def __init__(self, kernel_size: int = 7):
        super().__init__()
        if kernel_size % 2 != 1:
            raise ValueError("kernel_size must be odd")
        self.map_conv = nn.Conv2d(2, 1, kernel_size, padding=kernel_size // 2,
                                  bias=False)

    def attention_map(self, x: torch.Tensor) -> torch.Tensor:
        pooled = torch.cat((torch.amax(x, dim=1, keepdim=True),
                            torch.mean(x, dim=1, keepdim=True)), dim=1)
        return torch.sigmoid(self.map_conv(pooled))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x * self.attention_map(x)


class GlobalSelfAttention(nn.Module):
    """Global spatial scaled dot-product attention; O((H*W)^2) memory.

    1x1 Conv2d projections produce Q, K and V. By default each head uses
    channels // num_heads; total scaling sqrt(head_dim) matches usual MHA.
    The paper uses sqrt(C) for single-head, so heads=1 is algorithm-near.
    """
    def __init__(self, channels: int, heads: int = 1, max_tokens: int = 1024):
        super().__init__()
        if channels % heads:
            raise ValueError("channels must be divisible by heads")
        self.channels = channels
        self.heads = heads
        self.head_dim = channels // heads
        self.max_tokens = max_tokens
        self.q = nn.Conv2d(channels, channels, 1, bias=False)
        self.k = nn.Conv2d(channels, channels, 1, bias=False)
        self.v = nn.Conv2d(channels, channels, 1, bias=False)
        self.out = nn.Conv2d(channels, channels, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, h, w = x.shape
        n = h * w
        if n > self.max_tokens:
            raise ValueError(
                f"Global attention tokens {n} exceed max_tokens={self.max_tokens}. "
                "Downsample more, reduce input size, or explicitly raise the guard."
            )
        def reshape(projection: nn.Module) -> torch.Tensor:
            return projection(x).reshape(b, self.heads, self.head_dim, n).transpose(-2, -1)
        q, k, v = reshape(self.q), reshape(self.k), reshape(self.v)
        # Scaled dot product implemented explicitly to preserve formula visibility
        # (and make the attention map testable). Softmax is over KEY locations.
        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.head_dim)
        weights = torch.softmax(scores, dim=-1)
        attended = torch.matmul(weights, v)
        out = attended.transpose(-2, -1).reshape(b, c, h, w)
        return self.out(out)


class S3Attention(nn.Module):
    """Hybrid S3; 'algorithm' (addition) or 'diagram' (concat + conv + SiLU)."""
    def __init__(self, channels: int, *, mode: str = "s3", fusion: str = "algorithm",
                 heads: int = 1, spatial_kernel: int = 7, max_tokens: int = 1024):
        super().__init__()
        if mode not in {"none", "self", "spatial", "s3"}:
            raise ValueError(f"Unsupported S3 mode: {mode}")
        if fusion not in {"algorithm", "diagram"}:
            raise ValueError(f"Unsupported S3 fusion: {fusion}")
        self.mode, self.fusion = mode, fusion
        self.self_attn = (GlobalSelfAttention(channels, heads, max_tokens)
                          if mode in ("self", "s3") else None)
        self.spatial = SpatialAttention(spatial_kernel) if mode in ("spatial", "s3") else None
        self.diagram_fusion = (nn.Sequential(nn.Conv2d(2 * channels, channels, 1), nn.SiLU())
                               if mode == "s3" and fusion == "diagram" else None)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.mode == "none":
            return x
        if self.mode == "self":
            return self.self_attn(x)
        if self.mode == "spatial":
            return self.spatial(x)
        a, b = self.self_attn(x), self.spatial(x)
        if self.diagram_fusion is not None:
            return self.diagram_fusion(torch.cat([a, b], dim=1))
        return a + b
