"""Multi-stage feature extractor, reusable across classification domains."""
from __future__ import annotations
from torch import nn
from cxrnet.config import ModelConfig
from cxrnet.model.blocks import HierarchicalFusionStage
from cxrnet.model.attention import S3Attention


class CXRBackbone(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        stages = []
        in_channels = config.input_channels
        for i, out_channels in enumerate(config.channels):
            stages.append(HierarchicalFusionStage(
                in_channels, out_channels, first=i == 0, downsample=i > 0,
                fusion=config.fusion))
            in_channels = out_channels
        self.stages = nn.ModuleList(stages)
        self.attention = S3Attention(
            in_channels, mode=config.attention, fusion=config.s3_fusion,
            heads=config.attention_heads, spatial_kernel=config.spatial_kernel,
            max_tokens=config.attention_max_tokens,
        )
        self.output_channels = in_channels

    def forward(self, x):
        for stage in self.stages:
            x = stage(x)
        return self.attention(x)
