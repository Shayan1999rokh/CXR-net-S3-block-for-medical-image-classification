"""CBR building block and hierarchical two-branch feature fusion.

Figure 3 specifies CBR/concat topology but not kernels, widths or downsampling.
Kernel=3, progressive widths and stage boundary downsampling are engineering choices.
"""
from __future__ import annotations
import torch
from torch import nn
import torch.nn.functional as F


class CBR(nn.Sequential):
    """Conv2d -> BatchNorm2d -> ReLU as stated in Section 3.2."""
    def __init__(self, in_channels: int, out_channels: int, stride: int = 1,
                 kernel_size: int = 3):
        super().__init__(
            nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size,
                      padding=kernel_size // 2, stride=stride, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )


class HierarchicalFusionStage(nn.Module):
    """Two CBR paths then concatenate or sum, with explicit channel projection.

    The first stage uses 3 CBRs on the main branch; subsequent stages 2.
    The other branch has 2 CBRs. Mirrors figure-level motif, not exact original
    parameters, which are unavailable in the publication.
    """
    def __init__(self, in_channels: int, out_channels: int, *, first: bool = False,
                 downsample: bool = False, fusion: str = "concat"):
        super().__init__()
        if fusion not in ("concat", "sum"):
            raise ValueError("fusion must be concat or sum")
        first_stride = 2 if downsample else 1
        main = [CBR(in_channels, out_channels, stride=first_stride)]
        main.extend(CBR(out_channels, out_channels) for _ in range(2 if first else 1))
        self.main = nn.Sequential(*main)
        self.side = nn.Sequential(
            CBR(in_channels, out_channels, stride=first_stride), CBR(out_channels, out_channels)
        )
        self.fusion = fusion
        if fusion == "concat":
            self.project = CBR(out_channels * 2, out_channels, kernel_size=1)
        else:
            self.project = nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        a, b = self.main(x), self.side(x)
        fused = torch.cat((a, b), dim=1) if self.fusion == "concat" else a + b
        return self.project(fused)
