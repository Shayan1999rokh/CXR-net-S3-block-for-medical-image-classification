"""Classification head: GAP -> dense (2 hidden + final) -> logits.

The figure places 2D pooling after Flatten; impossible without reshape.
We resolve this by applying AdaptiveAvgPool2d before Flatten and two hidden
Dense layers, with dropout between. Softmax is used only at inference, not
before CrossEntropyLoss (which internally uses log-softmax).
"""
from __future__ import annotations
from torch import nn


class ClassificationHead(nn.Module):
    def __init__(self, channels: int, n_classes: int, hidden: list[int], dropout: float):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        dims = [channels, *hidden, n_classes]
        modules: list[nn.Module] = [self.pool, nn.Flatten(1)]
        for i in range(len(dims) - 1):
            modules.append(nn.Linear(dims[i], dims[i + 1]))
            if i < len(dims) - 2:
                modules.extend([nn.ReLU(inplace=True), nn.Dropout(dropout)])
        self.network = nn.Sequential(*modules)

    def forward(self, feature_map):
        return self.network(feature_map)  # raw logits, shape [B, num_classes]
