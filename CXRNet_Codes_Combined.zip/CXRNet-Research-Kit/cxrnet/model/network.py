"""CXR-Net as a single-task model and as a shared multi-domain backbone.

True multi-domain pretraining uses independent classification heads to avoid
pretending Chest/Bone/Shoulder classes share one target ontology.
"""
from __future__ import annotations
from dataclasses import asdict
from torch import nn
from cxrnet.config import ModelConfig
from cxrnet.model.backbone import CXRBackbone
from cxrnet.model.classifier import ClassificationHead


class CXRNet(nn.Module):
    def __init__(self, config: ModelConfig, n_classes: int):
        super().__init__()
        self.config = config
        self.backbone = CXRBackbone(config)
        self.head = ClassificationHead(
            self.backbone.output_channels, n_classes, config.classifier_hidden, config.dropout
        )

    def forward(self, x):
        return self.head(self.backbone(x))


class MultiDomainCXRNet(nn.Module):
    def __init__(self, config: ModelConfig, classes_per_domain: dict[str, int]):
        super().__init__()
        if not classes_per_domain:
            raise ValueError("Provide at least one pretraining domain")
        self.config = config
        self.backbone = CXRBackbone(config)
        self.heads = nn.ModuleDict({
            name: ClassificationHead(self.backbone.output_channels, count,
                                     config.classifier_hidden, config.dropout)
            for name, count in classes_per_domain.items()
        })

    def forward(self, x, domain: str):
        if domain not in self.heads:
            raise KeyError(f"Unknown domain {domain}")
        return self.heads[domain](self.backbone(x))

    def extract_single_domain(self, domain: str) -> CXRNet:
        """Copy task-specific head and shared weights without weights-from-test leakage."""
        model = CXRNet(self.config, self.heads[domain].network[-1].out_features)
        model.backbone.load_state_dict(self.backbone.state_dict())
        model.head.load_state_dict(self.heads[domain].state_dict())
        return model
