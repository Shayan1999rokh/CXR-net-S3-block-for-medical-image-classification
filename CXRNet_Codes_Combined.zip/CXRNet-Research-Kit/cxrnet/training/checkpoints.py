"""Artifact checkpoint I/O; never load untrusted arbitrary PyTorch pickle files."""
from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import torch

from cxrnet.config import ExperimentConfig
from cxrnet.model.network import CXRNet, MultiDomainCXRNet
from cxrnet.utils import provenance


def save_checkpoint(path: Path, model: torch.nn.Module, config: ExperimentConfig,
                    *, epoch: int, score: float, kind: str, domain: str | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "kind": kind, "domain": domain, "epoch": epoch, "monitor_score": float(score),
        "model_state": model.state_dict(),
        "config": config.to_dict(), "metadata": provenance(),
        "classes": {k: list(t.classes) for k, t in config.data.tasks.items()},
    }, path)


def read_checkpoint(path: str | Path) -> dict:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    # Restricted weights-only deserialization; use ONLY files created by this toolkit.
    return torch.load(path, map_location="cpu", weights_only=True)


def validate_checkpoint(checkpoint: dict, config: ExperimentConfig,
                        *, kind: str, domain: str | None = None) -> None:
    if checkpoint["kind"] != kind:
        raise ValueError(f"Expected checkpoint kind={kind}, got {checkpoint['kind']}")
    if kind == "single" and checkpoint["domain"] != domain:
        raise ValueError(f"Checkpoint domain mismatch: {checkpoint['domain']} vs {domain}")
    if checkpoint["config"]["model"] != config.to_dict()["model"]:
        raise ValueError("Model config differs from checkpoint; use original YAML architecture")
    for field in ("channels", "image_size", "contrast_method", "contrast_factor", "clahe_clip_limit", "clahe_tile_grid_size", "normalize_mean", "normalize_std"):
        if checkpoint["config"]["data"][field] != config.to_dict()["data"][field]:
            raise ValueError(f"Data preprocessing mismatch for {field}")
    for name, labels in checkpoint["classes"].items():
        if name not in config.data.tasks or labels != config.data.tasks[name].classes:
            raise ValueError(f"Checkpoint class ordering differs for {name}")


def load_single(path: str | Path, config: ExperimentConfig, domain: str,
                device: torch.device) -> CXRNet:
    payload = read_checkpoint(path)
    validate_checkpoint(payload, config, kind="single", domain=domain)
    model = CXRNet(config.model, len(config.data.tasks[domain].classes))
    model.load_state_dict(payload["model_state"], strict=True)
    model.to(device)
    return model


def load_pretrained_domain(path: str | Path, config: ExperimentConfig,
                           domain: str) -> CXRNet:
    payload = read_checkpoint(path)
    validate_checkpoint(payload, config, kind="multi")
    model = MultiDomainCXRNet(config.model,
                  {d: len(labels) for d, labels in payload["classes"].items()})
    model.load_state_dict(payload["model_state"], strict=True)
    if domain not in model.heads:
        raise KeyError(f"Domain {domain} not found in pretraining heads")
    return model.extract_single_domain(domain)
