"""Deterministic single-domain training, validation, and evaluation primitives."""
from __future__ import annotations

from contextlib import nullcontext
import numpy as np
import torch
from torch import nn

from cxrnet.evaluation.metrics import compute_metrics


def autocast_for(device: torch.device, enabled: bool):
    return torch.autocast(device_type="cuda") if enabled and device.type == "cuda" else nullcontext()


def make_scaler(device: torch.device, enabled: bool):
    return torch.amp.GradScaler("cuda", enabled=enabled and device.type == "cuda")


def train_epoch(model: nn.Module, loader, optimizer, criterion: nn.Module,
                device: torch.device, scaler, *, mixed_precision: bool, grad_clip: float) -> float:
    model.train()
    total_loss, n = 0.0, 0
    for images, labels in loader:
        images, labels = images.to(device, non_blocking=True), labels.to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        with autocast_for(device, mixed_precision):
            logits = model(images)
            loss = criterion(logits, labels)
        scaler.scale(loss).backward()
        if grad_clip > 0:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
        scaler.step(optimizer)
        scaler.update()
        total_loss += float(loss.detach()) * len(images)
        n += len(images)
    return total_loss / max(n, 1)


@torch.inference_mode()
def evaluate_loader(model: nn.Module, loader, criterion: nn.Module,
                    device: torch.device, class_names: list[str],
                    *, mixed_precision: bool = False, domain: str | None = None) -> tuple[dict, np.ndarray]:
    model.eval()
    labels_all, probs_all, total_loss, samples = [], [], 0.0, 0
    for images, targets in loader:
        images, targets = images.to(device, non_blocking=True), targets.to(device, non_blocking=True)
        with autocast_for(device, mixed_precision):
            logits = model(images) if domain is None else model(images, domain)
            loss = criterion(logits, targets)
        probs = torch.softmax(logits.float(), dim=1).cpu().numpy()
        labels_all.append(targets.cpu().numpy())
        probs_all.append(probs)
        total_loss += float(loss) * len(images)
        samples += len(images)
    if samples == 0:
        raise ValueError("Cannot evaluate empty dataset")
    probs_all = np.concatenate(probs_all)
    labels_all = np.concatenate(labels_all)
    report = compute_metrics(labels_all, probs_all, class_names)
    report["loss"] = total_loss / samples
    return report, probs_all


def score_to_minimize(report: dict, metric: str) -> float:
    if metric == "val_loss":
        return float(report["loss"])
    if metric == "val_accuracy":
        return -float(report["accuracy"])
    if metric == "val_macro_f1":
        return -float(report["macro_f1"])
    raise ValueError(f"Unsupported monitor {metric}")
