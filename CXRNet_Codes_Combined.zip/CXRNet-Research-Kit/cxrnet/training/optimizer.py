"""Optimizer, scheduler, loss and imbalance-policy setup."""
from __future__ import annotations
import math
import torch
from torch import nn
from cxrnet.config import TrainingConfig


def build_optimizer(parameters, cfg: TrainingConfig) -> torch.optim.Optimizer:
    if cfg.optimizer == "adamw":
        return torch.optim.AdamW(parameters, lr=cfg.learning_rate, weight_decay=cfg.weight_decay)
    if cfg.optimizer == "sgd":
        return torch.optim.SGD(parameters, lr=cfg.learning_rate, weight_decay=cfg.weight_decay,
                               momentum=0.9, nesterov=True)
    raise ValueError(f"Unsupported optimizer: {cfg.optimizer}")


def build_scheduler(optimizer, cfg: TrainingConfig, epochs: int):
    if cfg.scheduler == "none":
        return None
    return torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(epochs, 1), eta_min=cfg.min_learning_rate)


def make_criterion(cfg: TrainingConfig, targets: list[int], n_classes: int,
                   device: torch.device) -> nn.Module:
    weights = None
    if cfg.class_weighting == "inverse_frequency":
        counts = torch.bincount(torch.as_tensor(targets, dtype=torch.long),
                                minlength=n_classes).float()
        if torch.any(counts == 0):
            raise ValueError("Cannot build weights: class absent from training partition")
        weights = ((counts.sum() / (n_classes * counts)).float()).to(device)
    return nn.CrossEntropyLoss(weight=weights, label_smoothing=cfg.label_smoothing)
