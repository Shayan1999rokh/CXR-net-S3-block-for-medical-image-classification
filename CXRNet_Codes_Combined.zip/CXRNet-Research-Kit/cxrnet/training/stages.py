"""Two-stage, leakage-aware domain pretraining and independent fine-tuning.

Pretraining NEVER consumes test data; only each domain's train split is used.
Validation is used solely for model selection; independent test is evaluated
once after selecting the best single-domain checkpoint.
"""
from __future__ import annotations

import random
from pathlib import Path
import math

import torch
import pandas as pd
from tqdm.auto import tqdm

from cxrnet.config import ExperimentConfig, save_config
from cxrnet.data.datasets import get_loader
from cxrnet.model.network import CXRNet, MultiDomainCXRNet
from cxrnet.training.optimizer import build_optimizer, build_scheduler, make_criterion
from cxrnet.training.engine import (train_epoch, evaluate_loader, make_scaler,
                                    autocast_for, score_to_minimize)
from cxrnet.training.checkpoints import save_checkpoint, load_single, load_pretrained_domain
from cxrnet.evaluation.plots import plot_training_history, plot_confusion_matrix
from cxrnet.utils import seed_everything, write_json


def _history(path: Path, entries: list[dict]) -> None:
    path.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(entries).to_csv(path / "history.csv", index=False)
    write_json(path / "history.json", entries)


def _task_criterion(config: ExperimentConfig, domain: str, device: torch.device):
    ds = get_loader(config, domain, "train").dataset
    return make_criterion(config.train, ds.targets,
                          len(config.data.tasks[domain].classes), device)


def _run_training_single(config: ExperimentConfig, domain: str, device: torch.device,
                         *, initialized: CXRNet, run_directory: Path,
                         test_at_end: bool) -> dict:
    seed_everything(config.seed)
    save_config(config, run_directory)
    loader_train = get_loader(config, domain, "train")
    loader_val = get_loader(config, domain, "val")
    loader_test = get_loader(config, domain, "test") if test_at_end else None
    class_names = config.data.tasks[domain].classes
    model = initialized.to(device)
    criterion = make_criterion(config.train, loader_train.dataset.targets,
                               len(class_names), device)
    optimizer = build_optimizer(model.parameters(), config.train)
    scheduler = build_scheduler(optimizer, config.train, config.train.epochs)
    scaler = make_scaler(device, config.train.mixed_precision)
    best, stale = float("inf"), 0
    history: list[dict] = []
    checkpoint_path = run_directory / "best.pt"
    for epoch in range(1, config.train.epochs + 1):
        loss_train = train_epoch(model, loader_train, optimizer, criterion, device, scaler,
                                 mixed_precision=config.train.mixed_precision,
                                 grad_clip=config.train.grad_clip_norm)
        val_metrics, _ = evaluate_loader(model, loader_val, criterion, device, class_names,
                                          mixed_precision=config.train.mixed_precision)
        score = score_to_minimize(val_metrics, config.train.monitor)
        history.append({"epoch": epoch, "train_loss": loss_train,
                        "val_loss": val_metrics["loss"], "val_accuracy": val_metrics["accuracy"],
                        "val_macro_f1": val_metrics["macro_f1"],
                        "learning_rate": optimizer.param_groups[0]["lr"]})
        if score < best - 1e-8:
            best, stale = score, 0
            save_checkpoint(checkpoint_path, model, config, epoch=epoch, score=score,
                            kind="single", domain=domain)
        else:
            stale += 1
        if scheduler is not None:
            scheduler.step()
        print(f"[single:{domain}] {epoch}/{config.train.epochs} train_loss={loss_train:.4f} "
              f"val_loss={val_metrics['loss']:.4f} val_acc={val_metrics['accuracy']:.4f}")
        if stale >= config.train.early_stopping_patience > 0:
            print(f"Early stopping after epoch {epoch}")
            break
    _history(run_directory, history)
    plot_training_history(history, run_directory / "loss.png")
    result = {"best_checkpoint": str(checkpoint_path), "best_val_score": best,
              "best_epoch": int(torch.load(checkpoint_path, map_location="cpu", weights_only=True)["epoch"]),
              "domain": domain}
    if test_at_end:
        best_model = load_single(checkpoint_path, config, domain, device)
        test_metrics, probs = evaluate_loader(best_model, loader_test, criterion, device, class_names,
                                               mixed_precision=config.train.mixed_precision)
        write_json(run_directory / "test_metrics.json", test_metrics)
        plot_confusion_matrix(test_metrics["confusion_matrix"], class_names,
                              run_directory / "test_confusion_matrix.png")
        prediction_frame = loader_test.dataset.frame.copy()
        prediction_frame["predicted_label"] = [class_names[i] for i in probs.argmax(1)]
        for i, label in enumerate(class_names):
            prediction_frame[f"p_{label}"] = probs[:, i]
        prediction_frame.to_csv(run_directory / "test_predictions.csv", index=False)
        result["test_metrics"] = test_metrics
    write_json(run_directory / "summary.json", result)
    return result


def train_from_scratch(config: ExperimentConfig, domain: str, device: torch.device) -> dict:
    seed_everything(config.seed)
    model = CXRNet(config.model, len(config.data.tasks[domain].classes))
    return _run_training_single(config, domain, device, initialized=model,
                                run_directory=Path(config.run_dir) / f"scratch_{domain}",
                                test_at_end=True)


def finetune_from_pretraining(config: ExperimentConfig, domain: str,
                              checkpoint: str | Path, device: torch.device,
                              *, reset_head: bool = False) -> dict:
    seed_everything(config.seed)
    model = load_pretrained_domain(checkpoint, config, domain)
    if reset_head:
        fresh = CXRNet(config.model, len(config.data.tasks[domain].classes))
        fresh.backbone.load_state_dict(model.backbone.state_dict())
        model = fresh
    run_dir = Path(config.run_dir) / f"finetune_{domain}"
    return _run_training_single(config, domain, device, initialized=model,
                                run_directory=run_dir, test_at_end=True)


def pretrain_multidomain(config: ExperimentConfig, device: torch.device,
                         *, domains: list[str] | None = None) -> dict:
    """Train shared backbone with domain-specific heads on train folds only.

    Every train batch is seen once per epoch; batch order is shuffled across
    domains. Validation loss is sample-weighted across all domains.
    """
    seed_everything(config.seed)
    domains = domains or list(config.data.tasks)
    if not domains or any(d not in config.data.tasks for d in domains):
        raise ValueError(f"Invalid domains: {domains}")
    run_directory = Path(config.run_dir) / "pretraining"
    save_config(config, run_directory)
    model = MultiDomainCXRNet(config.model,
                              {domain: len(config.data.tasks[domain].classes) for domain in domains})
    model.to(device)
    train_loaders = {d: get_loader(config, d, "train") for d in domains}
    val_loaders = {d: get_loader(config, d, "val") for d in domains}
    criteria = {d: make_criterion(config.train, train_loaders[d].dataset.targets,
                                  len(config.data.tasks[d].classes), device) for d in domains}
    optimizer = build_optimizer(model.parameters(), config.train)
    scheduler = build_scheduler(optimizer, config.train, config.train.pretrain_epochs)
    scaler = make_scaler(device, config.train.mixed_precision)
    best, stale = float("inf"), 0
    history: list[dict] = []
    checkpoint = run_directory / "best.pt"
    for epoch in range(1, config.train.pretrain_epochs + 1):
        model.train()
        domain_iterators = {d: iter(train_loaders[d]) for d in domains}
        schedule = [d for d in domains for _ in range(len(train_loaders[d]))]
        random.Random(config.seed + epoch).shuffle(schedule)
        losses, n = 0.0, 0
        for domain in schedule:
            images, labels = next(domain_iterators[domain])
            images = images.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with autocast_for(device, config.train.mixed_precision):
                prediction = model(images, domain)
                loss = criteria[domain](prediction, labels)
            scaler.scale(loss).backward()
            if config.train.grad_clip_norm > 0:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), config.train.grad_clip_norm)
            scaler.step(optimizer)
            scaler.update()
            losses += float(loss.detach()) * len(labels)
            n += len(labels)
        val_reports = {}
        val_loss_sum = 0.0
        val_count = 0
        for domain in domains:
            report, _ = evaluate_loader(model, val_loaders[domain], criteria[domain], device,
                                         config.data.tasks[domain].classes,
                                         mixed_precision=config.train.mixed_precision,
                                         domain=domain)
            val_reports[domain] = report
            val_loss_sum += report["loss"] * report["n_samples"]
            val_count += report["n_samples"]
        val_loss = val_loss_sum / val_count
        val_acc = sum(r["accuracy"] for r in val_reports.values()) / len(domains)
        val_f1 = sum(r["macro_f1"] for r in val_reports.values()) / len(domains)
        history.append({"epoch": epoch, "train_loss": losses / max(n, 1),
                        "val_loss": val_loss, "val_accuracy": val_acc,
                        "val_macro_f1": val_f1, "learning_rate": optimizer.param_groups[0]["lr"]})
        current = score_to_minimize({"loss": val_loss, "accuracy": val_acc,
                                     "macro_f1": val_f1}, config.train.monitor)
        if current < best - 1e-8:
            best, stale = current, 0
            save_checkpoint(checkpoint, model, config, epoch=epoch, score=best, kind="multi")
            write_json(run_directory / "best_validation_by_domain.json", val_reports)
        else:
            stale += 1
        if scheduler is not None:
            scheduler.step()
        print(f"[pretrain] {epoch}/{config.train.pretrain_epochs} "
              f"train_loss={losses / max(n, 1):.4f} val_loss={val_loss:.4f}")
        if stale >= config.train.early_stopping_patience > 0:
            print(f"Pretraining early stopping after {epoch}")
            break
    _history(run_directory, history)
    plot_training_history(history, run_directory / "loss.png")
    result = {"best_checkpoint": str(checkpoint), "best_val_score": best,
              "domains": domains,
              "NOTE": "No test split used in pretraining or model selection"}
    write_json(run_directory / "summary.json", result)
    return result
