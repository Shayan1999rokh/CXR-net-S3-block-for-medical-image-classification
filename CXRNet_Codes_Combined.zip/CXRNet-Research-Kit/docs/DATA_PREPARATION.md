# Data intake, manifest, and split rules

## Actual paper datasets (download separately)

The manuscript points to Kermany et al. 2018 Chest X-ray, Rodrigo 2023 Bone Fracture Multi-Region and Yari 2023 Shoulder. You must honor each dataset's license and verify whether original split metadata, labels and patient IDs are available. Links and raw images are **not** bundled.

## File layout

Use either `data/raw/<domain>/<label>/...` (unsplit) or `data/raw/<domain>/<split>/<label>/...` (already split, with `train`, `val` and `test`). Per-domain class names **must** exactly match `configs/default.yaml`. Case sensitivity is intentional, to avoid silent remapping. An optional CSV maps images to patients:

```csv
path,patient_id
chest/normal/p001_view1.jpg,CH_P001
chest/normal/p001_view2.jpg,CH_P001
chest/viral_pneumonia/p002.jpg,CH_P002
```

The `patient_id` must be from actual metadata, **not inferred from labels**, unless filenames are independently documented to encode unique patients. If using site-specific IDs, prefix with site names. `patient_id` is blank when unavailable.

## Split policy

- For fully organized source `train/val/test`, preserve them by default. Verify that source partitions are patient-independent; automatic checking detects conflicts only if IDs are supplied.
- For unpartitioned data with **complete** patient IDs, stratify on unique patients directly when each patient has a single label (two-stage group-level StratifiedShuffleSplit). For patients who have multiple class labels, attempt a reproducible 10-fold StratifiedGroupKFold partition (7 train / 2 validation / 1 test). Fractions are approximate when groups have different numbers of images. Small group counts may fail explicitly.
- For unpartitioned data without full IDs, use image-level stratified sampling 70/20/10 and emit a warning. **Not appropriate for defensible medical performance claims.**
- Unknown classes, missing image folders, unreadable image bytes and empty classes/splits are errors.
- Exact SHA256 duplicate images across partitions are rejected by default; this may require time and disk I/O. Hash checks can be disabled for debugging but not for a serious research evaluation.
- No contrast choice, augmentation or hyperparameter search is based on the test set. Test predictions are collected only after validation selects the checkpoint.

## Data limitations not resolved by this package

Age/sex/site confounding, inaccurate labels, class definitions, patient overlap when no IDs are supplied, inter-reader reliability, equipment acquisition differences, image leakage by near-duplicates, shortcut features/markers, and class-conditioned augmentation artifacts require dataset-specific checks. Prevent unintentional dataset mixing by keeping original data provenance alongside CSVs.

## Normalization / color

All images are converted to 1 channel by default; optional RGB requires changing both `data.channels`, mean/std arrays and `model.input_channels` to 3. All inputs use PIL bilinear resizing, contrast adjustment, tensor conversion, and mean/std normalization. Images are 8-bit PIL-converted; when original clinical images are DICOM or >8-bit PNG/TIFF, build a modality-aware decoder and document windowing before relying on quantitative comparisons.

## Suggested baseline workflow

1. Start with original author train/validation/test when provided; otherwise use real patient-level split.
2. Audit duplicate bytes and class distributions.
3. Train a scratch CNN with `attention: none`.
4. Run self-only, spatial-only, full S3 variants using same held-out validation.
5. Freeze configuration, then evaluate test once.
6. For publication, repeat with several random seeds and report means/SD/CIs, per-class sensitivity and center-level performance.
