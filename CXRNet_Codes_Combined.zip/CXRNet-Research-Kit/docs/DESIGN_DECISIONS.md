# Architecture decisions and assumptions

## Clarified source contradictions

1. **S3:** Figure 4 has an apparent role-label inversion between QKV pathway and pooled spatial pathway. Algorithm 1 specifies **addition**, Figure 4 a **concat/Conv/SiLU** fusion. Both are selectable. Default is `algorithm`.
2. **S3 scale:** Algorithm 1 uses `sqrt(C)` and appears single-head. The code additionally inserts an output 1x1 convolution after the attention value projection, not specified by the pseudocode. Config defaults to 4-head, each scaled by `sqrt(C / heads)`. To match its scalar denominator more closely set `attention_heads: 1`, and ensure final channels divisible by 1.
3. **Classifier:** The print ordering of Flatten and 2D AvgPool cannot be used naively with normal tensor ranks. Head uses AdaptiveAvgPool2d before Flatten. This removes feature-size-dependent dense parameter counts. Three fully connected layers = two hidden + one logits.
4. **CBR:** Figure 3 illustrates a hierarchical two-branch concatenation structure but omits exact channels, kernels, strides, padding, and whether the skip projection has normalization. The code chooses 3x3 kernels, five stages, first 3+2 CBR layers then 2+2, channel progression 32/64/96/128/160, 2x downsample at stages 2–5, and learnable 1x1 projection after concatenation. These are **not confirmed original architecture values**.
5. **Image size:** 224 by default; not a paper-specified resolution.
6. **Optimizer:** AdamW, LR=3e-4, weight decay=1e-4, cosine schedule, dropout=0.3 are practical defaults, **not source-grounded** hyperparameters.
7. **Pretraining:** Paper says 200 epochs on pooled 23,547 images then 100 epochs per task. Its handling of task heads, test partition and repeated images is not disclosed. We train a shared backbone plus independent heads using only training folds and validate on held-out validation subsets.
8. **Contrast:** PIL `ImageEnhance.Contrast(image).enhance(1.4)` makes "40%" precise, but may differ from actual algorithm used in paper.
9. **Augmentation:** Online train-only HFlip and ±10° rotation, VFlip off. Paper lists HFlip, VFlip, rotation without numeric parameters. Train balancing uses repeated sampling of minority training images under independent random augmentation, rather than using transformed copies of test images.
10. **Loss:** Standard categorical CrossEntropyLoss on logits; label smoothing optional. Never pass softmax probabilities to this loss.

## Attention complexity and constraints

For a feature map of shape `[B, C, H, W]`, scaled dot-product spatial attention has `N=H*W` tokens and attention score shape `[B, heads, N, N]`. Full attention is quadratic in N. The implementation caps N at 1,024 by default and raises an explicit error rather than silently downsampling. At 224 input and five stages with four spatial downsampling steps, the last map is roughly 14x14, so N ~196.

## Patient identity

Without patient metadata, no algorithm can guarantee that two images from a patient end up in the same split. Enable `require_patient_ids: true` and supply IDs for clinical research. IDs are treated as globally unique across domains. If ID namespaces differ between hospitals, prefix site IDs before passing them. Byte hashes detect exact duplicates, but not crops, transforms, repeated acquisitions or near-duplicates.

## Evaluation caution

- Test data are never accessed during hyperparameter selection, pretraining or ablation validation.
- Test metrics are computed from individual predictions, not per-batch average of metrics.
- AUC is null when undefined (e.g., an absent class).
- Accuracy 100% on a held-out split does **not** imply 100% clinical sensitivity.
- Independent patient/device/site validation and interval estimates are required to support clinical claims.
- For repeated architecture comparisons, use an external final holdout only after freezing the method.
