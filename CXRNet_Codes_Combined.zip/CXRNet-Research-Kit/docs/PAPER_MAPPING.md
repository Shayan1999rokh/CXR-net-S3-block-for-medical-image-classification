# Paper-to-code traceability

This table maps manuscript structure to Python modules; it does **not** claim access to authors' training scripts.

| Source (PDF page) | Described paper component | Python module(s) | Fidelity / caveat |
|---|---|---|---|
| Section 3, Fig. 1 (p. 5) | Import, preprocessing, split, train, evaluate | `data/manifest.py`, `data/splitting.py`, `training/stages.py` | Test isolation is explicitly strengthened |
| Section 3.1 (p. 6) | Image preprocessing | `data/transforms.py`, `data/datasets.py` | PIL `Contrast(1.4)` inferred, not paper-exact |
| Fig. 2, Section 3.2 (p. 6) | Feature extractor plus classifier | `model/backbone.py`, `model/classifier.py`, `model/network.py` | Unpublished widths, input size, head ordering resolved in code |
| Fig. 3, Section 3.2 (p. 7–8) | CBR with skip/concat | `model/blocks.py` | Two-branch fusion motif; widths, stride and projection choices are assumptions |
| Fig. 4 (p. 9) | QKV and spatial components; concatenation/Conv/SiLU | `model/attention.py` `fusion='diagram'` | Approximation to figure; branch labels in figure appear reversed |
| Algorithm 1 (p. 10) | Q,K,V, scaled attention, pooled spatial mask, additive fusion | `model/attention.py` `fusion='algorithm'` | Direct structural implementation; multi-head is an enhancement |
| Classifier text (p. 10), Fig. 2 | Flatten, dense, avgpool, dropout, softmax | `model/classifier.py` | GAP first; logits training with CE |
| Section 3.3 (p. 11) | Classification metrics | `evaluation/metrics.py` | Corrects Eq. (3), mislabeled accuracy as recall in print |
| Section 4.1, Table 1 (pp. 11–14) | Three domains, 9 mutually domain-specific labels | `configs/default.yaml`, `data/manifest.py` | No patient metadata provided by paper |
| Table 2 (p. 15) | Contrast method comparison | `data/transforms.py`, `evaluation/contrast_sweep.py` | PIL-factor/histogram/CLAHE comparisons are supported; not identical source formulation |
| Table 3 (p. 16) | Class balancing augmentation | `data/balancing.py`, `data/transforms.py` | Class-balanced train epochs, not augmentation of validation/test |
| Section 4.2, Fig. 9 (p. 17) | 200-epoch multi-domain pretraining | `training/stages.py` `pretrain_multidomain` | Domain heads (engineering choice); train-only |
| Section 4.2, Figs. 10 and Table 4 (p. 18) | 100-epoch task fine-tuning | `training/stages.py` `finetune_from_pretraining` | Early stop/checkpoints on validation only |
| Table 5 (p. 19) | Comparison with prior papers | `evaluation/ablations.py`; benchmark functions | Literature SOTA not automatically reproduced; not same splits |
| Section 4.3, Table 6 (p. 21) | Generalization evaluation | `evaluation/metrics.py`, independent test workflow | Original Table 4 vs 6 protocols unclear; external dataset validation not supplied |
| Section 4.4 (pp. 21–22) | Limitations | `data/audit.py`, `evaluation/metrics.py` | Leakage checks, per-class metrics, patient IDs |
| Section 5 (pp. 22–24) | Proposed future XAI | `evaluation/explain.py` | Grad-CAM provided as enhancement, not a paper experiment |
| Section 5 (pp. 22–24) | Few-shot, semi-supervised, federated, CapsNet | Not implemented | Proposed future work is not confused with performed research |

## Original reported dataset sizes / claims

- Chest original 5,856 (Normal 1,583; bacterial 2,780; viral 1,493), augmented to 9,000.
- Fracture original 10,547 (fractured 5,181; not fractured 5,366); article says already augmented.
- Shoulder original class table totals **838** (57 + 57 + 172 + 552), while prose says **841**; article augmented to 4,000.
- Article Table 4 reports 99.82 / 100.00 / 97.53% accuracy; Table 6 94.6 / 91.2 / 88.5%. Different test protocols are not explained adequately. **Neither set of metrics is bundled as code-generated evidence.**
- The abstract reports losses as percentages but does not specify the exact loss function.

## How to claim a genuine replication

Record original splits and patient/site IDs; specify every hyperparameter; obtain or infer author architecture from author code, if available; train multiple seeds; publish confusion matrices and sample-level predictions; benchmark against controlled baselines; evaluate external radiographs. Until then, characterize results as an independent implementation/inspired reproduction.
