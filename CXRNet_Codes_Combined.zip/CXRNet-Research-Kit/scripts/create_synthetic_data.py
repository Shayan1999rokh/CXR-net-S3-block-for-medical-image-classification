"""Generate synthetic image FILES only for validating code execution.

These random shapes/noises are NOT clinical radiographs, and numerical scores
obtained from them have no scientific meaning.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw


TASKS = {"chest": ["normal", "bacterial_pneumonia", "viral_pneumonia"],
         "fracture": ["fractured", "not_fractured"],
         "shoulder": ["a1", "c1", "d1", "others"]}


def make_synthetic_data(output: Path, per_class: int = 16, size: int = 64) -> None:
    """The seed is unique for each image, avoiding byte-duplicate leakage checks."""
    if per_class < 12:
        raise ValueError("At least 12 per class recommended to populate all test folds")
    for domain_index, (domain, labels) in enumerate(TASKS.items()):
        for class_index, label in enumerate(labels):
            directory = output / domain / label
            directory.mkdir(parents=True, exist_ok=True)
            for i in range(per_class):
                rng = np.random.default_rng(100_000 * domain_index + 1000 * class_index + i)
                pixels = rng.normal(75 + class_index * 25, 18, (size, size)).clip(0, 255).astype(np.uint8)
                image = Image.fromarray(pixels, mode="L")
                drawer = ImageDraw.Draw(image)
                x = int((i * 7 + class_index * 13) % (size // 2))
                drawer.ellipse((x, 8, x + 14, 22), outline=200, width=2)
                image.save(directory / f"synthetic_{i:03}.png")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("data/raw"))
    parser.add_argument("--per-class", type=int, default=16)
    parser.add_argument("--size", type=int, default=64)
    args = parser.parse_args()
    make_synthetic_data(args.output, args.per_class, args.size)
    print(f"Created synthetic test files at {args.output}")
