"""Lightweight fixtures, independent of external clinical data."""
from __future__ import annotations
from pathlib import Path
import pytest
from cxrnet.config import load_config


@pytest.fixture
def small_config():
    config = load_config(Path(__file__).resolve().parents[1] / "configs" / "default.yaml")
    config.data.image_size = 32
    config.model.channels = [8, 12]
    config.model.attention_heads = 4
    config.train.batch_size = 4
    config.train.num_workers = 0
    config.train.epochs = 1
    config.train.pretrain_epochs = 1
    config.train.early_stopping_patience = 0
    config.model.classifier_hidden = [12, 8]
    config.data.split.verify_duplicate_hashes = True
    config.validate()
    return config
