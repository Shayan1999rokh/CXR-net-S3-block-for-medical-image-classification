import torch
import pytest
from cxrnet.model.blocks import CBR, HierarchicalFusionStage
from cxrnet.model.attention import GlobalSelfAttention, SpatialAttention, S3Attention
from cxrnet.model.network import CXRNet, MultiDomainCXRNet


def test_cbr_and_concat():
    x = torch.randn(2, 1, 32, 32)
    cbr = CBR(1, 8)
    assert cbr(x).shape == (2, 8, 32, 32)
    stage = HierarchicalFusionStage(1, 8, first=True, downsample=True, fusion="concat")
    assert stage(x).shape == (2, 8, 16, 16)
    stage2 = HierarchicalFusionStage(1, 8, first=True, downsample=True, fusion="sum")
    assert stage2(x).shape == (2, 8, 16, 16)


@pytest.mark.parametrize("mode,fusion", [("none", "algorithm"), ("self", "algorithm"),
                                         ("spatial", "algorithm"), ("s3", "algorithm"),
                                         ("s3", "diagram")])
def test_s3_modes_and_gradients(mode, fusion):
    x = torch.randn(2, 12, 5, 5, requires_grad=True)
    module = S3Attention(12, mode=mode, fusion=fusion, heads=4, spatial_kernel=7)
    y = module(x)
    assert y.shape == x.shape
    assert torch.isfinite(y).all()
    y.square().mean().backward()
    assert x.grad is not None and torch.isfinite(x.grad).all()


def test_global_attention_token_limit():
    x = torch.randn(2, 12, 5, 5)
    layer = GlobalSelfAttention(12, heads=4, max_tokens=12)
    with pytest.raises(ValueError, match="exceed"):
        layer(x)


def test_single_and_multidomain(small_config):
    x = torch.randn(2, 1, 32, 32)
    single = CXRNet(small_config.model, n_classes=3)
    logits = single(x)
    assert logits.shape == (2, 3)
    torch.nn.functional.cross_entropy(logits, torch.tensor([0, 2])).backward()
    multi = MultiDomainCXRNet(small_config.model, {"chest": 3, "fracture": 2})
    assert multi(x, "chest").shape == (2, 3)
    assert multi(x, "fracture").shape == (2, 2)
    extracted = multi.extract_single_domain("fracture")
    multi.eval(); extracted.eval()
    with torch.no_grad():
        assert torch.allclose(multi(x, "fracture"), extracted(x), atol=1e-6)
