from pathlib import Path
import pytest
import torch
from cxrnet.config import load_config
from cxrnet.model.network import CXRNet, MultiDomainCXRNet
from cxrnet.training.checkpoints import (save_checkpoint, read_checkpoint,
                                          load_single, load_pretrained_domain)


def test_config_validation(small_config):
    small_config.data.channels = 3
    with pytest.raises(ValueError, match="channels"):
        small_config.validate()


def test_single_checkpoint(tmp_path, small_config):
    model = CXRNet(small_config.model, 3)
    path = tmp_path / "best.pt"
    save_checkpoint(path, model, small_config, epoch=1, score=0.4, kind="single", domain="chest")
    loaded = load_single(path, small_config, "chest", torch.device("cpu"))
    model.eval(); loaded.eval()
    x = torch.randn(2, 1, 32, 32)
    with torch.inference_mode():
        assert torch.allclose(model(x), loaded(x), atol=1e-6)
    with pytest.raises(ValueError, match="domain mismatch"):
        load_single(path, small_config, "shoulder", torch.device("cpu"))


def test_pretrained_checkpoint_task_head(tmp_path, small_config):
    model = MultiDomainCXRNet(small_config.model, {"chest": 3, "fracture": 2, "shoulder": 4})
    path = tmp_path / "pretrain.pt"
    save_checkpoint(path, model, small_config, epoch=3, score=0.2, kind="multi")
    derived = load_pretrained_domain(path, small_config, "fracture")
    x = torch.randn(2, 1, 32, 32)
    model.eval(); derived.eval()
    with torch.inference_mode():
        assert torch.allclose(model(x, "fracture"), derived(x), atol=1e-6)
