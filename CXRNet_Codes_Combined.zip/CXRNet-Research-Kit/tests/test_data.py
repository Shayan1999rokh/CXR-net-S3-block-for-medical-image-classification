from pathlib import Path
import pandas as pd
import pytest
import torch
from cxrnet.data.balancing import BalancedEpochSampler
from cxrnet.data.manifest import index_images, load_manifest
from cxrnet.data.splitting import (split_manifest, assert_no_patient_overlap,
                                    assert_no_file_hash_overlap)
from cxrnet.data.datasets import get_loader
from scripts.create_synthetic_data import make_synthetic_data


def test_sampler_exact_counts_and_determinism():
    targets = [0, 0, 0, 1, 1, 2]
    a = BalancedEpochSampler(targets, seed=123)
    b = BalancedEpochSampler(targets, seed=123)
    x = list(a); y = list(b)
    assert x == y and len(x) == 9
    assert [sum(targets[i] == k for i in x) for k in range(3)] == [3, 3, 3]
    assert list(a) != x  # different epoch sample order


def test_index_split_dataset(tmp_path, small_config):
    cfg = small_config
    cfg.data.root = str(tmp_path / "raw")
    cfg.data.manifest = str(tmp_path / "manifests" / "raw.csv")
    cfg.data.split_manifest = str(tmp_path / "manifests" / "splits.csv")
    make_synthetic_data(Path(cfg.data.root), per_class=16, size=32)
    indexed = index_images(cfg.data)
    assert len(indexed) == 144
    with pytest.warns(UserWarning, match="NOT patient-safe"):
        splits = split_manifest(cfg.data, cfg.seed)
    assert len(splits) == 144
    assert set(splits.split) == {"train", "val", "test"}
    assert_no_patient_overlap(splits)
    assert_no_file_hash_overlap(splits, Path(cfg.data.root))
    loader = get_loader(cfg, "chest", "train")
    images, targets = next(iter(loader))
    assert images.shape == (4, 1, 32, 32)
    assert targets.shape == (4,)


def test_patient_overlap_rejected():
    frame = pd.DataFrame({"patient_id": ["p1", "p1"], "split": ["train", "test"]})
    with pytest.raises(ValueError, match="Patient IDs"):
        assert_no_patient_overlap(frame)


def test_patient_group_split_with_multiple_images_per_patient(tmp_path, small_config):
    """Multiple images from one patient must remain in a single partition."""
    cfg = small_config
    cfg.data.root = str(tmp_path / "raw")
    cfg.data.manifest = str(tmp_path / "manifest.csv")
    cfg.data.split_manifest = str(tmp_path / "splits.csv")
    cfg.data.split.require_patient_ids = False
    # 20 distinct groups per class, 2 images each for all task labels.
    make_synthetic_data(Path(cfg.data.root), per_class=40, size=32)
    indexed = index_images(cfg.data)
    def patient_id(row):
        # Every consecutive image pair is one subject; domain+label+id avoids alias collisions.
        return f"{row.domain}_{row.label}_{int(Path(row.path).stem.split('_')[-1]) // 2:03d}"
    indexed["patient_id"] = indexed.apply(patient_id, axis=1)
    mapping_path = tmp_path / "patient_map.csv"
    indexed[["path", "patient_id"]].to_csv(mapping_path, index=False)
    cfg.data.split.require_patient_ids = True
    indexed = index_images(cfg.data, patient_map_csv=str(mapping_path))
    result = split_manifest(cfg.data, cfg.seed)
    assert result.patient_id.ne("").all()
    assert result.groupby("patient_id").split.nunique().max() == 1
