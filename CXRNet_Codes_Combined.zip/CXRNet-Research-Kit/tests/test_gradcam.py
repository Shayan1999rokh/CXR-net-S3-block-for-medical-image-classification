import torch
from cxrnet.model.network import CXRNet
from cxrnet.evaluation.explain import GradCAM


def test_gradcam_shape_and_normalization(small_config):
    model = CXRNet(small_config.model, 3)
    with GradCAM(model, model.backbone.stages[-1]) as explain:
        heatmap, label = explain(torch.randn(1, 1, 32, 32))
    assert heatmap.shape == (1, 1, 32, 32)
    assert 0 <= label < 3
    assert heatmap.min() >= 0 and heatmap.max() <= 1
