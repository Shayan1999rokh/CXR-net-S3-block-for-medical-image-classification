"""Opt-in heavier end-to-end test; run with `pytest -m integration`."""
from pathlib import Path
import torch
import pytest
from scripts.create_synthetic_data import make_synthetic_data
from cxrnet.data.manifest import index_images
from cxrnet.data.splitting import split_manifest
from cxrnet.training.stages import pretrain_multidomain, finetune_from_pretraining


@pytest.mark.integration
def test_pretrain_and_finetune_one_epoch(tmp_path, small_config):
    cfg = small_config
    cfg.data.root = str(tmp_path / "raw")
    cfg.data.manifest = str(tmp_path / "manifest.csv")
    cfg.data.split_manifest = str(tmp_path / "splits.csv")
    cfg.run_dir = str(tmp_path / "runs")
    make_synthetic_data(Path(cfg.data.root), per_class=16, size=32)
    index_images(cfg.data)
    with pytest.warns(UserWarning):
        split_manifest(cfg.data, cfg.seed)
    pre = pretrain_multidomain(cfg, torch.device("cpu"))
    assert Path(pre["best_checkpoint"]).exists()
    fin = finetune_from_pretraining(cfg, "chest", pre["best_checkpoint"], torch.device("cpu"))
    assert Path(fin["best_checkpoint"]).exists()
    assert fin["test_metrics"]["n_samples"] > 0
