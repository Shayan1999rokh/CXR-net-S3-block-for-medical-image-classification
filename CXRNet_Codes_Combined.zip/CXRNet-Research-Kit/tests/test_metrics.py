import numpy as np
import pytest
from cxrnet.evaluation.metrics import compute_metrics, expected_calibration_error


def test_perfect_binary_metrics():
    m = compute_metrics([0, 1, 0, 1], np.array([[.98,.02],[.01,.99],[.99,.01],[.02,.98]]), ["a", "b"])
    assert m["accuracy"] == 1.0
    assert m["macro_f1"] == 1.0
    assert m["roc_auc"] == 1.0
    assert m["per_class"]["a"]["specificity"] == 1.0
    assert m["confusion_matrix"] == [[2, 0], [0, 2]]


def test_multiclass_shapes_and_absent_auc():
    y = [0, 0, 1]
    p = np.array([[0.9, .05, .05], [.7, .2, .1], [.1, .7, .2]])
    m = compute_metrics(y, p, ["a", "b", "c"])
    assert m["n_samples"] == 3
    assert m["roc_auc"] is None
    assert m["per_class"]["c"]["support"] == 0
    assert 0 <= m["expected_calibration_error"] <= 1


def test_bad_probability_is_rejected():
    with pytest.raises(ValueError):
        compute_metrics([0], np.array([[0.7, 0.7]]), ["a", "b"])
