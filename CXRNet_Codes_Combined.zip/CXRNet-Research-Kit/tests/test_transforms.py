from PIL import Image
import pytest
import torch
from cxrnet.data.transforms import ContrastTransform, build_transforms


def test_enhancement_methods(small_config):
    image = Image.new("L", (32, 32), color=120)
    for method in ("factor", "none", "equalize"):
        transformed = ContrastTransform(method, factor=1.4)(image)
        assert transformed.size == (32, 32)
        assert transformed.mode == "L"
    cfg = small_config.data
    assert build_transforms(cfg, train=False)(image).shape == (1, 32, 32)
    assert torch.isfinite(build_transforms(cfg, train=True)(image)).all()


def test_contrast_reject_invalid():
    with pytest.raises(ValueError):
        ContrastTransform("magic")
